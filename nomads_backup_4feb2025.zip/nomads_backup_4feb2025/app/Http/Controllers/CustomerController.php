<?php
namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Company;
use App\Models\CustomerManager;
use App\Models\Service;
use App\Models\Country;
use App\Models\State;
use App\Models\City;
use App\Models\Reference;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;


class CustomerController extends Controller
{
    public function index()
    {
        $customers = Customer::active()->with(['country', 'state', 'city', 'reference'])->orderByDesc('id')->get();
        $services = Service::active()->get();
        return view('homecontent.customer.index', compact('customers', 'services'));
    }

    public function create()
    {
        try {
            $data['customers'] = Customer::all();
            $data['services'] = Service::all();
            $data['countries'] = Country::all();
            // $data['states'] = State::all();
            // $data['cities'] = City::all();
            $data['references'] = Reference::all();

            return view('homecontent.customer.create', $data);
        } catch (\Exception $e) {

            \Log::error('Error retrieving data for customer creation: ' . $e->getMessage());


            return redirect()->back()->with('error', 'An error occurred while retrieving the data. Please try again.');
        }
    }

    public function store(Request $request)
    {
        //dd($request->all());
        try {
            $rules = [
                'fname' => 'required|string|max:255',
                'lname' => 'required|string|max:255',
                'email' => 'required|email|max:255|unique:customers,email',
                'gender' => 'required|in:Male,Female,Other',
                'mobile' => [
                    'required', 'string', 'max:20', 'unique:customers,mobile',
                    function ($attribute, $value, $fail) {
                        if (!preg_match('/^\+\d{10,15}$/', $value)) {
                            $fail('The ' . $attribute . ' field must be a valid international phone number in E.164 format.');
                        }
                    },
                ],
                'whatsapp' => [
                    'nullable', 'string', 'max:20', 'unique:customers,whatsapp',
                    function ($attribute, $value, $fail) {
                        if ($value && !preg_match('/^\+\d{10,15}$/', $value)) {
                            $fail('The ' . $attribute . ' field must be a valid international phone number in E.164 format.');
                        }
                    },
                ],
                'locality' => 'nullable|string|max:500',
                'pincode' => 'nullable',
                'country_id' => 'nullable|int|exists:countries,id',
                'state_id' => 'nullable|int|exists:states,id',
                'city_id' => 'nullable|int|exists:cities,id',
                'reference_id' => 'nullable|int|exists:references,id',
                'have_manager' => 'required|boolean',
                'have_company' => 'required|boolean',
            ];

            // Additional rules based on conditionals
            if ($request->input('have_manager') == 1) {
                $rules = array_merge($rules, [
                    'manager_fname' => 'required|string|max:255',
                    'manager_lname' => 'required|string|max:255',
                    'manager_mobile' => [
                        'required', 'string', 'max:20',
                        function ($attribute, $value, $fail) {
                            if (!preg_match('/^\+\d{10,15}$/', $value)) {
                                $fail('The ' . $attribute . ' field must be a valid international phone number in E.164 format.');
                            }
                        },
                    ],
                    'manager_whatsapp' => [
                        'nullable', 'string', 'max:20',
                        function ($attribute, $value, $fail) {
                            if (!preg_match('/^\+\d{10,15}$/', $value)) {
                                $fail('The ' . $attribute . ' field must be a valid international phone number in E.164 format.');
                            }
                        },
                    ],
                    'manager_email' => 'nullable|string|email|max:255',
                    'manager_position' => 'nullable|string|max:255',
                ]);
            }

            if ($request->input('have_company') == 1) {
                $rules = array_merge($rules, [
                    'company_name' => 'required|string|max:255',
                    'company_mobile' => [
                        'nullable', 'string', 'max:20',
                        function ($attribute, $value, $fail) {
                            if (!preg_match('/^\+\d{10,15}$/', $value)) {
                                $fail('The ' . $attribute . ' field must be a valid international phone number in E.164 format.');
                            }
                        },
                    ],
                    'company_gst' => 'nullable|string|max:15',
                    'company_address' => 'nullable|string|max:500',
                ]);
            }

            // Validation
            $validator = Validator::make($request->all(), $rules);

            if ($validator->fails()) {
                return redirect()->back()->withInput()->withErrors($validator);
            }

            // Process the validated data here
            $validatedData = $validator->validated();

            $data = [
                'fname' => $validatedData['fname'],
                'lname' => $validatedData['lname'],
                'email' => $validatedData['email'],
                'gender' => $validatedData['gender'],
                'mobile' => $validatedData['mobile'],
                'whatsapp' => $validatedData['whatsapp'],
                'locality' => $validatedData['locality'],
                'pincode' => $validatedData['pincode'],
                'country_id' => $validatedData['country_id'],
                'state_id' => $validatedData['state_id'],
                'city_id' => $validatedData['city_id'],
                'reference_id' => $validatedData['reference_id'],
                'have_manager' => $validatedData['have_manager'],
                'have_company' => $validatedData['have_company'],
                'added_by' => Auth::id(),
            ];

            $customer = Customer::create($data);

            if ($request->input('have_manager')) {
                CustomerManager::create([
                    'customer_id' => $customer->id,
                    'fname' => $validatedData['manager_fname'],
                    'lname' => $validatedData['manager_lname'],
                    'mobile' => $validatedData['manager_mobile'],
                    'whatsapp' => $validatedData['manager_whatsapp'],
                    'email' => $validatedData['manager_email'],
                    'relation' => $validatedData['manager_position'],
                    'added_by' => Auth::id(),
                ]);
            }

            if ($request->input('have_company')) {
                Company::create([
                    'customer_id' => $customer->id,
                    'name' => $validatedData['company_name'],
                    'mobile' => $validatedData['company_mobile'],
                    'gst' => $validatedData['company_gst'],
                    'address' => $validatedData['company_address'],
                    'added_by' => Auth::id(),
                ]);
            }

            return redirect()->route('customers.index')->with('success', 'Customer created successfully.');
        } catch (\Exception $e) {
            \Log::error('Error creating customer: ' . $e->getMessage());
            return redirect()->back()->withInput()->with('error', 'An error occurred while creating the customer. Please try again.'.$e->getMessage());
        }
    }

    public function update(Request $request, Customer $customer)
    {

        try {
            $validatedData = $request->validate([
                'fname' => 'required|string|max:255',
                'lname' => 'required|string|max:255',
                'email' => 'nullable|email|max:255|unique:customers,email,' . $customer->id . ',id,is_deleted,0',
                'gender' => 'nullable|in:Male,Female,Other',
                'mobile' => 'required|string|max:15|unique:customers,mobile,' . $customer->id . ',id,is_deleted,0',
                'whatsapp' => 'required|string|max:15|unique:customers,whatsapp,' . $customer->id . ',id,is_deleted,0',
                'locality' => 'nullable|string|max:500',
                'pincode' => 'nullable',
                'country_id' => 'nullable|int|exists:countries,id',
                'state_id'   => 'nullable|int|exists:states,id',
                'city_id'    => 'nullable|int|exists:cities,id',
                'reference_id'  => 'nullable|int|exists:references,id',
                'have_manager' => 'nullable|boolean',
            ]);


            $data = [
                'fname' => $validatedData['fname'],
                'lname' => $validatedData['lname'],
                'email' => $validatedData['email'],
                'gender' => $validatedData['gender'],
                'mobile' => $validatedData['mobile'],
                'whatsapp' => $validatedData['whatsapp'],
                'locality' => $validatedData['locality'],
                'pincode' => $validatedData['pincode'],
                'country_id' => $validatedData['country_id'],
                'state_id' => $validatedData['state_id'],
                'city_id' => $validatedData['city_id'],
                'reference_id' => $validatedData['reference_id'],
                'have_manager' => $validatedData['have_manager'] ?? 0,
                'updated_by' => Auth::id(),
            ];

            $customer->update($data);

            if (!empty($request->input('manager_fname'))) {
                $managerValidatedData = $request->validate([
                    'manager_fname' => 'required|string|max:255',
                    'manager_lname' => 'required|string|max:255',
                    'manager_mobile' => 'required|string|max:15',
                    'manager_whatsapp' => 'nullable|string|max:15',
                    'manager_email' => 'nullable|string|email|max:255|unique:customer_managers,email',
                    'manager_position' => 'nullable|string|max:255',
                ]);

                $managerData = [
                    'customer_id' => $customer->id,
                    'fname' => $managerValidatedData['manager_fname'] ,
                    'lname' => $managerValidatedData['manager_lname'],
                    'mobile' => $managerValidatedData['manager_mobile'],
                    'whatsapp' => $managerValidatedData['manager_whatsapp'],
                    'email' => $managerValidatedData['manager_email'],
                    'relation' => $managerValidatedData['manager_position'],
                ];

                CustomerManager::create($managerData);
                $customer->update(['have_manager' => true]);
            }
            // else {
            //     // If 'have_manager' is not checked, delete the associated manager record if it exists
            //     if ($customer->managers()->count() > 0) {
            //         $customer->managers()->delete();
            //     }
            // }

            return redirect()->route('customers.index')->with('success', 'Customer updated successfully.');
        } catch (\Exception $e) {
            \Log::error('Customer Update Error: ' . $e->getMessage());
            return redirect()->back()->withInput()->with('error', 'An error occurred while updating the customer. Please try again.'. $e->getMessage());
        }
    }

    public function show(Customer $customer)
    {

        $services = Service::active()->get();

        return view('homecontent.customer.show', compact('customer', 'services'));
    }

    public function edit(Customer $customer)
    {
        $data['customer'] = $customer;
        $data['services'] = Service::all();
        $data['countries'] = Country::all();
        // $data['states'] = State::all();
        // $data['cities'] = City::all();
        $data['references'] = Reference::all();
        return view('homecontent.customer.edit', $data);
    }

    public function destroy(Customer $customer)
    {
        try {

            DB::beginTransaction();

            $customer->softDelete();

            if ($customer->have_manager) {

                $manager = $customer->manager;
                if ($manager) {
                    $manager->softDelete();
                }
            }

            if ($customer->have_company) {

                $company = $customer->company;
                if ($company) {
                    $company->softDelete();
                }
            }

            DB::commit();

            return redirect()->route('customers.index')->with('success', 'Customer and related entities deleted successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->route('customers.index')->with('error', 'An error occurred while deleting the customer. Please try again.');
        }
    }

    public function storeForBooking(Request $request)
    {

        try {
            $messages = [
                'mobile.required' => 'Mobile number is required.',
                'gender.required' => 'Gender is required.',
                'mobile.unique' => 'This mobile number is already registered.',
                'whatsapp.unique' => 'This WhatsApp number is already registered.',
                'email.email' => 'Please provide a valid email address.',
                'email.unique' => 'This email address is already registered.',
            ];

            if($request->have_manager){
                $validatedData = $request->validate([
                    'fname' => 'required|string|max:255',
                    'lname' => 'required|string|max:255',
                    'gender' => 'required|in:Male,Female,Other',
                    'locality' => 'nullable|string|max:500',
                    'pincode' => 'nullable|digits:6',
                    'country_id' => 'nullable|int|exists:countries,id',
                    'state_id' => 'nullable|int|exists:states,id',
                    'city_id' => 'nullable|int|exists:cities,id',
                    'reference_id' => 'nullable|int|exists:references,id',
                    'have_manager' => 'required|boolean',
                    'have_company' => 'required|boolean',
                ], $messages);
            }else{
                $validatedData = $request->validate([
                    'fname' => 'required|string|max:255',
                    'lname' => 'required|string|max:255',
                    'email' => 'nullable|email|max:255|unique:customers,email',
                    'gender' => 'nullable|in:Male,Female,Other',
                    'mobile' => [
                        'required', 'string', 'max:20', 'unique:customers,mobile',
                        function ($attribute, $value, $fail) {
                            if (!preg_match('/^\+\d{10,15}$/', $value)) {
                                $fail('The ' . $attribute . ' field must be a valid international phone number in E.164 format.');
                            }
                        },
                    ],
                    'whatsapp' => [
                        'nullable', 'string', 'max:20', 'unique:customers,whatsapp',
                        function ($attribute, $value, $fail) {
                            if ($value && !preg_match('/^\+\d{10,15}$/', $value)) {
                                $fail('The ' . $attribute . ' field must be a valid international phone number in E.164 format.');
                            }
                        },
                    ],
                    'locality' => 'nullable|string|max:500',
                    'pincode' => 'nullable|digits:6',
                    'country_id' => 'nullable|int|exists:countries,id',
                    'state_id' => 'nullable|int|exists:states,id',
                    'city_id' => 'nullable|int|exists:cities,id',
                    'reference_id' => 'nullable|int|exists:references,id',
                    'have_manager' => 'required|boolean',
                    'have_company' => 'required|boolean',
                ], $messages);
            }



            $validatedData['added_by'] = Auth::id();

            $customer = Customer::create($validatedData);

            return response()->json([
                'success' => true,
                'message' => 'Customer saved successfully.',
                'customer_id' => $customer->id,
                'customer_name' => $customer->fname . ' ' . $customer->lname,
                'customer_gender' => $customer->gender,
                'have_manager' => $customer->have_manager,
            ], 200);
        }
        catch (\Illuminate\Validation\ValidationException $e) {
            return response()->json([
                'success' => false,
                'message' => 'Please enter valid customer details.',
                'errors' => $e->errors()
            ], 422);
        }
        catch (\Exception $e) {
            // Log the exception for debugging
            \Log::error('Customer Store Error: '.$e->getMessage());

            return response()->json([
                'success' => false,
                'message' => 'An unexpected error occurred while saving the customer. Please try again later.'
            ], 500);
        }
    }

    public function searchCustomers(Request $request)
    {
        $query = $request->input('query');
        $customers = Customer::active()
            ->whereRaw('LOWER(fname) LIKE ?', ["%".strtolower($query)."%"])
            ->orWhereRaw('LOWER(lname) LIKE ?', ["%".strtolower($query)."%"])
            ->get();

        return response()->json(['customers' => $customers]);
    }

    public function getStates($countryId)
    {
        $states = State::where('country_id', $countryId)->get();

        return response()->json($states);
    }

    public function getCities($stateId)
    {
        $cities = City::where('state_id', $stateId)->get();

        return response()->json($cities);
    }
}
