<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="py-3 px-2">
                        <h3 class="font-weight-bold text-primary">Edit Followups</h3>
                    </div>
                    <div class="text-right p-2">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm btn-primary">
                            Back
                        </a>
                    </div>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Followups Details</h6>
                        </div>
                        <div class="card-body">

                                <form action="<?php echo e(route('followups.update', $followup->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="row">
                                        <div class="form-group col col-6 mb-3">
                                            <label for="enquiry_id">Enquiry</label>
                                            <select name="enquiry_id" id="enquiry_id" class="form-control form-select" required>
                                                <option value="">Select Enquiry</option>
                                                <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($enquiry->id); ?>" <?php echo e($enquiry->id == $followup->enquiry_id ? 'selected' : ''); ?>>
                                                        <?php echo e($enquiry->fname); ?> <?php echo e($enquiry->lname); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group col col-6 mb-3">
                                            <label for="user_id">User</label>
                                            <select name="user_id" id="user_id" class="form-control form-select" required>
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($user->id); ?>" <?php echo e($user->id == $followup->user_id ? 'selected' : ''); ?>>
                                                        <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group col col-6 mb-3">
                                            <label for="followup_date">Follow-Up Date</label>
                                            <input type="date" name="followup_date" id="followup_date" class="form-control" value="<?php echo e(old('followup_date', $followup->followup_date)); ?>" required>
                                        </div>

                                        <div class="form-group col col-6 mb-3">
                                            <label for="followup_time">Follow-Up Time</label>
                                            <input type="time" name="followup_time" id="followup_time" class="form-control" value="<?php echo e(old('followup_time', $followup->followup_time)); ?>">
                                        </div>

                                        <div class="form-group col col-6 mb-3">
                                            <label for="remarks">Remarks</label>
                                            <textarea name="remarks" id="remarks" class="form-control" rows="4"><?php echo e(old('remarks', $followup->remarks)); ?></textarea>
                                        </div>

                                        <div class="form-group col col-6 mb-3">
                                            <label for="followup_type">Follow-Up Type</label>
                                            <select name="followup_type" id="followup_type" class="form-control form-select" required>
                                                <option value="routine_followup" <?php echo e($followup->followup_type == 'routine_followup' ? 'selected' : ''); ?>>Routine Follow-Up</option>
                                                <option value="schedule_meeting" <?php echo e($followup->followup_type == 'schedule_meeting' ? 'selected' : ''); ?>>Schedule Meeting</option>
                                            </select>
                                        </div>

                                        <div class="form-group col col-6 mb-3">
                                            <label for="status">Status</label>
                                            <select name="status" id="status" class="form-control form-select" required>
                                                <option value="active" <?php echo e($followup->status == 'active' ? 'selected' : ''); ?>>Active</option>
                                                <option value="inactive" <?php echo e($followup->status == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                            </select>
                                        </div>
                                    </div>



                        </div>
                        <div class="card-footer mt-4 text-center">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

             <!-- Footer -->
             @include('shared.footer')
 <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/followup/edit.blade.php ENDPATH**/ ?>
