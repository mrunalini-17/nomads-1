<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<style>

.popup-message {
    position: fixed;
    bottom: 40px;
    right: 40px;
    background-color: #4caf50; /* Green for success */
    color: white;
    padding: 10px 20px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
    z-index: 1000;
    font-size: 16px;
    opacity: 0;
    transform: translateY(20px);
    animation: fadeInOut 3s ease forwards;
}

.popup-message.error {
    background-color: #f44336;
}

@keyframes fadeInOut {
    0% {
        opacity: 0;
        transform: translateY(20px);
    }
    10% {
        opacity: 1;
        transform: translateY(0);
    }
    90% {
        opacity: 1;
        transform: translateY(0);
    }
    100% {
        opacity: 0;
        transform: translateY(20px);
    }
}



.table-success {
    background-color: #d4edda !important;
}


</style>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Topbar -->
            <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Topbar -->

            <!-- Main Content -->
            <div id="content">
                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                        <!-- Total Bookings -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-primary shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                                <a href="" style="color:#4e73df!important;">Total Bookings</a>
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($bookings); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-calendar-check fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Enquiries -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-info shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                                                <a href="" style="color:#36b9cc!important;">Total Enquiries</a>
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($enquiries); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Customers -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-warning shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                                                <a href="" style="color:#f6c23e!important;">Total Customers</a>
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($customers); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-user-friends fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Total Employees -->
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card border-left-success shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="row no-gutters align-items-center">
                                        <div class="col mr-2">
                                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                <a href="" style="color:#1cc88a!important;">Total Employees</a>
                                            </div>
                                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($employees); ?></div>
                                        </div>
                                        <div class="col-auto">
                                            <i class="fas fa-users fa-2x text-gray-300"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Content Row -->
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('accounts')): ?>
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Deliverables</h6>
                        </div>
                        <div class="card-body">
                            <!-- Tab Navigation -->
                            <ul class="nav nav-tabs" id="tabMenu" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link active" id="section1-tab" data-bs-toggle="tab" href="#section1"
                                        role="tab" aria-controls="section1" aria-selected="true">Today</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="section2-tab" data-bs-toggle="tab" href="#section2"
                                        role="tab" aria-controls="section2" aria-selected="false">Tommorow</a>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <a class="nav-link" id="section3-tab" data-bs-toggle="tab" href="#section3"
                                        role="tab" aria-controls="section3" aria-selected="false">Day after tommorow</a>
                                </li>

                            </ul>

                                <!-- Tab Content -->
                                <div class="tab-content" id="tabContent">
                                    <!-- Today -->
                                    <div class="tab-pane fade show active" id="section1" role="tabpanel" aria-labelledby="section1-tab">

                                        <table class="table " id="dataTable1" cellspacing="0" style="font-size: 14px;">
                                            <thead class="bg-light text-dark">
                                                <tr>
                                                    <th>Sr No</th>
                                                    <th>Booking ID</th>
                                                    <th>Customer</th>
                                                    <th>Service</th>
                                                    <th>Confirmation No</th>
                                                    
                                                    <th>Note</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $rowNumber = 1; ?>
                                                <?php $__currentLoopData = $todaysBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todaysBooking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $todaysBooking->bookingServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            // Fetch the confirmation for the relevant date
                                                            $confirmation = $service->bookingConfirmations->first();
                                                        ?>
                                                        <tr class="<?php echo e($confirmation && $confirmation->is_delivered ? 'table-success' : ''); ?>">
                                                            <td><?php echo e($rowNumber++); ?></td>
                                                            <td><?php echo e($todaysBooking->unique_code); ?></td>
                                                            <td><?php echo e($todaysBooking->customer->fname); ?> <?php echo e($todaysBooking->customer->lname); ?></td>
                                                            <td><?php echo e($service->service_details); ?></td>
                                                            <td><?php echo e($service->confirmation_number); ?></td>
                                                            
                                                            <td>
                                                                <?php if($confirmation && $confirmation->note): ?>
                                                                    <?php echo e($confirmation->note); ?>

                                                                <?php else: ?>
                                                                    <div class="form-floating">
                                                                        <?php $__currentLoopData = $service->bookingConfirmations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confirmation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <textarea class="form-control form-control-sm"
                                                                                  placeholder="Add note..."
                                                                                  id="note_<?php echo e($confirmation->id); ?>"
                                                                                  name="note_<?php echo e($confirmation->id); ?>"
                                                                                  style="height: auto"
                                                                                  <?php echo e($confirmation && $confirmation->is_delivered ? 'disabled' : ''); ?>>
                                                                        </textarea>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <div class="text-center">
                                                                    <?php $__currentLoopData = $service->bookingConfirmations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confirmation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <button type="button"
                                                                                class="btn btn-sm btn-primary update-btn"
                                                                                id="update_<?php echo e($confirmation->id); ?>"
                                                                                data-confirmation-id="<?php echo e($confirmation->id); ?>"
                                                                                data-service-id="<?php echo e($service->id); ?>"
                                                                                <?php echo e($confirmation->is_delivered ? 'disabled' : ''); ?>>
                                                                            <i class="fas fa-check"></i>
                                                                        </button>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>


                                    </div>


                                    <!-- Tommorow-->
                                    <div class="tab-pane fade" id="section2" role="tabpanel" aria-labelledby="section2-tab">
                                        <table class="table " id="dataTable2" cellspacing="0" style="font-size: 14px;">
                                            <thead class="bg-light text-dark">
                                                <tr>
                                                    <th>Sr No</th>
                                                    <th>Booking ID</th>
                                                    <th>Customer</th>
                                                    <th>Service</th>
                                                    <th>Confirmation No</th>
                                                    
                                                    <th>Note</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $rowNumber = 1; ?>
                                                <?php $__currentLoopData = $tomorrowsBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tomorrowsBooking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $tomorrowsBooking->bookingServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            // Fetch the confirmation for the relevant date
                                                            $confirmation = $service->bookingConfirmations->first();
                                                        ?>
                                                        <tr class="<?php echo e($confirmation && $confirmation->is_delivered ? 'table-success' : ''); ?>">
                                                            <td><?php echo e($rowNumber++); ?></td>
                                                            <td><?php echo e($tomorrowsBooking->unique_code); ?></td>
                                                            <td><?php echo e($tomorrowsBooking->customer->fname); ?> <?php echo e($tomorrowsBooking->customer->lname); ?></td>
                                                            <td><?php echo e($service->service_details); ?></td>
                                                            <td><?php echo e($service->confirmation_number); ?></td>
                                                            
                                                            <td>
                                                                <?php if($confirmation && $confirmation->note): ?>
                                                                    <?php echo e($confirmation->note); ?>

                                                                <?php else: ?>
                                                                    <div class="form-floating">
                                                                        <?php $__currentLoopData = $service->bookingConfirmations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confirmation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <textarea class="form-control form-control-sm"
                                                                                  placeholder="Add note..."
                                                                                  id="note_<?php echo e($confirmation->id); ?>"
                                                                                  name="note_<?php echo e($confirmation->id); ?>"
                                                                                  style="height: auto"
                                                                                  <?php echo e($confirmation && $confirmation->is_delivered ? 'disabled' : ''); ?>>
                                                                        </textarea>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <div class="text-center">
                                                                    <?php $__currentLoopData = $service->bookingConfirmations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confirmation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <button type="button"
                                                                                class="btn btn-sm btn-primary update-btn"
                                                                                id="update_<?php echo e($confirmation->id); ?>"
                                                                                data-confirmation-id="<?php echo e($confirmation->id); ?>"
                                                                                data-service-id="<?php echo e($service->id); ?>"
                                                                                <?php echo e($confirmation->is_delivered ? 'disabled' : ''); ?>>
                                                                            <i class="fas fa-check"></i>
                                                                        </button>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>

                                        </table>


                                    </div>

                                    <!-- Day after Tommorow-->
                                    <div class="tab-pane fade" id="section3" role="tabpanel" aria-labelledby="section3-tab">
                                        <table class="table " id="dataTable3" cellspacing="0" style="font-size: 14px;">
                                            <thead class="bg-light text-dark">
                                                <tr>
                                                    <th>Sr No</th>
                                                    <th>Booking ID</th>
                                                    <th>Customer</th>
                                                    <th>Service</th>
                                                    <th>Confirmation No</th>
                                                    
                                                    <th>Note</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $rowNumber = 1; ?>
                                                <?php $__currentLoopData = $dayAfterTomorrowsBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datBookings): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $datBookings->bookingServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                            // Fetch the confirmation for the relevant date
                                                            $confirmation = $service->bookingConfirmations->first();
                                                        ?>
                                                        <tr class="<?php echo e($confirmation && $confirmation->is_delivered ? 'table-success' : ''); ?>">
                                                            <td><?php echo e($rowNumber++); ?></td>
                                                            <td><?php echo e($datBookings->unique_code); ?></td>
                                                            <td><?php echo e($datBookings->customer->fname); ?> <?php echo e($datBookings->customer->lname); ?></td>
                                                            <td><?php echo e($service->service_details); ?></td>
                                                            <td><?php echo e($service->confirmation_number); ?></td>
                                                            
                                                            <td>
                                                                <?php if($confirmation && $confirmation->note): ?>
                                                                    <?php echo e($confirmation->note); ?>

                                                                <?php else: ?>
                                                                    <div class="form-floating">
                                                                        <?php $__currentLoopData = $service->bookingConfirmations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confirmation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <textarea class="form-control form-control-sm"
                                                                                  placeholder="Add note..."
                                                                                  id="note_<?php echo e($confirmation->id); ?>"
                                                                                  name="note_<?php echo e($confirmation->id); ?>"
                                                                                  style="height: auto"
                                                                                  <?php echo e($confirmation && $confirmation->is_delivered ? 'disabled' : ''); ?>>
                                                                        </textarea>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <div class="text-center">
                                                                    <?php $__currentLoopData = $service->bookingConfirmations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $confirmation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <button type="button"
                                                                                class="btn btn-sm btn-primary update-btn"
                                                                                id="update_<?php echo e($confirmation->id); ?>"
                                                                                data-confirmation-id="<?php echo e($confirmation->id); ?>"
                                                                                data-service-id="<?php echo e($service->id); ?>"
                                                                                <?php echo e($confirmation->is_delivered ? 'disabled' : ''); ?>>
                                                                            <i class="fas fa-check"></i>
                                                                        </button>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>

                                        </table>


                                    </div>
                                </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>



<script>
    document.addEventListener('DOMContentLoaded', function () {
        const updateButtons = document.querySelectorAll('.update-btn');

        updateButtons.forEach(button => {
            button.addEventListener('click', function () {
                const confirmationId = $(this).data('confirmation-id');
                const serviceId = $(this).data('service-id');
                const note = document.querySelector(`#note_${confirmationId}`);

                // Disable button to prevent multiple clicks
                this.disabled = true;

                // Get the CSRF token
                const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                // Make the fetch request to update the service
                fetch('<?php echo e(route("bookings.updateservice")); ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        confirmation_id: confirmationId,
                        service_id: serviceId,
                        note: note ? note.value.trim() : ''
                    })
                })
                .then(response => response.json())
                .then(data => {
                    const messageBox = document.createElement('div');
                    messageBox.className = 'popup-message';
                    if (data.success) {
                        messageBox.innerText = 'Service updated successfully!';
                        const tableRow = document.querySelector(`button[data-confirmation-id="${confirmationId}"]`).closest('tr');
                            if (tableRow) {
                                tableRow.classList.add('table-success');
                            }
                    } else {
                        messageBox.innerText = 'Failed to update service: ' + data.message;
                        messageBox.classList.add('error');
                    }
                    document.body.appendChild(messageBox);

                    setTimeout(() => {
                        messageBox.remove();
                    }, 3000);
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while updating the service.');
                });
            });
        });
    });
</script>

<script>
    $(document).ready(function () {
        $('#dataTable1, #dataTable2, #dataTable3').each(function () {
            $(this).DataTable({
                columnDefs: [
                    {
                        targets: [-1, -2],
                        orderable: false
                    }
                ]
            });
        });
    });

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4new\htdocs\nomads\resources\views/index.blade.php ENDPATH**/ ?>