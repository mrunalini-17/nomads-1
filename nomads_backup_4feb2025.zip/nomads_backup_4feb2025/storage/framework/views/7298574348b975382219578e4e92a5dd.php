<?php $__env->startSection('title', 'Edit Customer'); ?>
<?php $__env->startSection('content'); ?>

<style>
    .iti{
        display : block;
    }
</style>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="text-right p-2">
                        <a href="<?php echo e(route('customers.index')); ?>" class="btn btn-sm btn-primary">Back</a>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Edit Customer</h6>
                        </div>
                        <form action="<?php echo e(route('customers.update', $customer->id)); ?>" method="POST" id="customerForm">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="card-body">
                                    <div class="row">
                                        <div class="mb-3 col col-6">
                                            <label for="fname" class="form-label">First Name<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="fname" name="fname" value="<?php echo e(old('fname', $customer->fname)); ?>" required>
                                            <?php $__errorArgs = ['fname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3 col col-6">
                                            <label for="lname" class="form-label">Last Name<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="lname" name="lname" value="<?php echo e(old('lname', $customer->lname)); ?>" required>
                                            <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>




                                        <div class="mb-3 col col-6">
                                            <label for="mobile" class="form-label">Mobile<span class="text-danger">*</span></label>
                                            <input type="tel" class="form-control" id="mobile" name="mobile" min="0" value="<?php echo e(old('mobile', $customer->mobile)); ?>" required oninput="document.getElementById('whatsapp').value = this.value;">
                                            <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3 col col-6">
                                            <label for="whatsapp" class="form-label">WhatsApp</label>
                                            <input type="tel" class="form-control" id="whatsapp" name="whatsapp" min="0" value="<?php echo e(old('whatsapp', $customer->whatsapp)); ?>">
                                            <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3 col col-6">
                                            <label for="email" class="form-label">Email</label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', $customer->email)); ?>" required>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3 col-md-6">
                                            <label for="gender" class="form-label">Gender</label>
                                            <select class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="gender" name="gender" required>
                                                <option value="" disabled>Select Gender</option>
                                                <option value="Male" <?php echo e(old('gender', $customer->gender) == 'Male' ? 'selected' : ''); ?>>Male</option>
                                                <option value="Female" <?php echo e(old('gender', $customer->gender) == 'Female' ? 'selected' : ''); ?>>Female</option>
                                                <option value="Other" <?php echo e(old('gender', $customer->gender) == 'Other' ? 'selected' : ''); ?>>Other</option>
                                            </select>
                                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>


                                        <div class="mb-3 col col-6">
                                            <label for="address" class="form-label">Locality <span class="text-danger">*</span></label>
                                            <textarea class="form-control" id="locality" name="locality" rows="1"><?php echo e(old('locality', $customer->locality)); ?></textarea>
                                            <?php $__errorArgs = ['locality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="mb-3 col col-6">
                                            <label for="pincode" class="form-label">Pincode</label>
                                            <input type="number" class="form-control" id="pincode" name="pincode" value="<?php echo e(old('pincode', $customer->pincode)); ?>">
                                            <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>



                                        <div class="mb-3 col col-6">
                                            <div class="form-group">
                                                <label for="country_id">Country <span class="text-danger">*</span></label>
                                                <select class="form-control <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    id="country_id" name="country_id" required>
                                                    <option value="">Select Country</option>
                                                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($country->id); ?>"
                                                            <?php echo e(old('country_id',$customer->country_id) == $country->id ? 'selected' : ''); ?>>
                                                            <?php echo e($country->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>


                                            <div class="mb-3 col col-6">
                                                <div class="form-group">
                                                    <label for="state_id">State <span class="text-danger">*</span></label>
                                                    <select class="form-control <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="state_id" name="state_id" required>
                                                        <option value="">Select State</option>
                                                        
                                                    </select>
                                                    <?php $__errorArgs = ['state_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="mb-3 col col-6">
                                                <div class="form-group">
                                                    <label for="city_id">City <span class="text-danger">*</span></label>
                                                    <select class="form-control <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="city_id" name="city_id" required>
                                                        <option value="">Select City</option>
                                                        
                                                    </select>
                                                    <?php $__errorArgs = ['city_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            <div class="mb-3 col col-6">
                                                <div class="form-group">
                                                    <label for="reference_id">Reference </label>
                                                    <select class="form-control <?php $__errorArgs = ['reference_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        id="reference_id" name="reference_id">
                                                        <option value="">Select reference</option>
                                                        <?php $__currentLoopData = $references; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($reference->id); ?>"
                                                                <?php echo e(old('reference_id',$customer->reference_id) == $reference->id ? 'selected' : ''); ?>>
                                                                <?php echo e($reference->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['reference_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                            
                                    </div>

                                    <div class="row d-none" id="manager_information">
                                        <!-- Manager Information Form Fields -->
                                        <div class="col-12 card-header py-3 mb-3 d-flex justify-content-between align-items-center">
                                            <h6 class="font-weight-bold text-primary mb-0">Manager Details</h6>
                                            <button type="button" class="close" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>


                                        <div class="mb-3 col-md-6">
                                            <label for="fname" class="form-label">First Name  <span class="text-danger"><sup>*</sup></span></label>
                                            <input type="text" class="form-control" id="manager_fname" name="manager_fname">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label for="lname" class="form-label">Last Name <span class="text-danger"><sup>*</sup></span></label>
                                            <input type="text" class="form-control" id="manager_lname" name="manager_lname">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label for="manager_mobile" class="form-label">Mobile <span class="text-danger"><sup>*</sup></span></label>
                                            <input type="tel" class="form-control" id="manager_mobile" name="manager_mobile"min="0">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label for="manager_whatsapp" class="form-label">WhatsApp</label>
                                            <input type="tel" class="form-control" id="manager_whatsapp" name="manager_whatsapp" min="0">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label for="manager_email" class="form-label">Email</label>
                                            <input type="email" class="form-control" id="manager_email" name="manager_email">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label for="manager_position" class="form-label">Relation</label>
                                            <input type="text" class="form-control" id="manager_position" name="manager_position">
                                            <small class="form-text text-muted">e.g., PA, Manager, Admin, etc.</small>
                                        </div>

                                    </div>
                            </div>


                            <div class="card-footer">
                                <div class="text-center"> <button type="submit" class="btn btn-success">Submit</button></div>
                            </div>
                        </form>
                    </div>

                                                        <!-- Manager Details -->
                                                        <?php if($customer->managers->isNotEmpty()): ?>
                                                            <div class="card mb-4">
                                                                <div class="card-header">
                                                                    <h5 class="card-title">Manager Information</h5>
                                                                </div>
                                                                <div class="card-body">
                                                                    <table class="table table-striped">
                                                                        <?php $__currentLoopData = $customer->managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <tr>
                                                                                <th>Name</th>
                                                                                <td><?php echo e($manager->fname ?? 'NA'); ?> <?php echo e($manager->lname ?? 'NA'); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th>Mobile</th>
                                                                                <td><?php echo e($manager->mobile ?? 'NA'); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th>WhatsApp</th>
                                                                                <td><?php echo e($manager->whatsapp ?? 'NA'); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th>Email</th>
                                                                                <td><?php echo e($manager->email ?? 'NA'); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <th>Position</th>
                                                                                <td><?php echo e($manager->relation ?? 'NA'); ?></td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td colspan="2">
                                                                                    <div class="text-end">
                                                                                        <!-- Button to edit the manager -->
                                                                                        <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editManagerModal<?php echo e($manager->id); ?>">
                                                                                            Edit Manager
                                                                                        </button>
                                                                                        <!-- Form to delete the manager -->
                                                                                        <form action="<?php echo e(route('customer-managers.destroy', $manager->id)); ?>" method="POST" style="display:inline;">
                                                                                            <?php echo csrf_field(); ?>
                                                                                            <?php echo method_field('DELETE'); ?>
                                                                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this manager?');">Delete Manager</button>
                                                                                        </form>
                                                                                    </div>
                                                                                </td>
                                                                            </tr>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="card mb-4" id="no_manager">
                                                                <div class="card-header d-flex justify-content-between align-items-center">
                                                                    <h5 class="card-title mb-0">No Manager Assigned</h5>
                                                                    <button class="btn btn-success" id="add_manager">Add Manager</button>
                                                                </div>
                                                                <div class="card-body">
                                                                    <p>No managers have been assigned to this customer.</p>
                                                                </div>

                                                            </div>
                                                        <?php endif; ?>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
        <!-- Edit manager Modal -->
        <?php $__currentLoopData = $customer->managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="modal fade" id="editManagerModal<?php echo e($manager->id); ?>" tabindex="-1" aria-labelledby="editManagerModalLabel<?php echo e($manager->id); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editManagerModalLabel<?php echo e($manager->id); ?>">Manager Information</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('customer-managers.update', $manager->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <!-- Manager Information Form Fields -->
                                    <div class="mb-3 col col-6">
                                        <label for="fname<?php echo e($manager->id); ?>" class="form-label">First Name <span class="text-danger"><sup>*</sup></span></label>
                                        <input type="text" class="form-control" id="fname<?php echo e($manager->id); ?>" name="manager_fname" value="<?php echo e($manager->fname); ?>" required>
                                    </div>
                                    <div class="mb-3 col col-6">
                                        <label for="lname<?php echo e($manager->id); ?>" class="form-label">Last Name <span class="text-danger"><sup>*</sup></span></label>
                                        <input type="text" class="form-control" id="lname<?php echo e($manager->id); ?>" name="manager_lname" value="<?php echo e($manager->lname); ?>" required>
                                    </div>
                                    <div class="mb-3 col col-6">
                                        <label for="manager_mobile<?php echo e($manager->id); ?>" class="form-label">Mobile <span class="text-danger"><sup>*</sup></span></label>
                                        <input type="tel" class="form-control" id="manager_mobile<?php echo e($manager->id); ?>" name="manager_mobile" value="<?php echo e($manager->mobile); ?>" required>
                                    </div>
                                    <div class="mb-3 col col-6">
                                        <label for="manager_whatsapp<?php echo e($manager->id); ?>" class="form-label">WhatsApp <span class="text-danger"><sup>*</sup></span></label>
                                        <input type="tel" class="form-control" id="manager_whatsapp<?php echo e($manager->id); ?>" name="manager_whatsapp" value="<?php echo e($manager->whatsapp); ?>">
                                    </div>
                                    <div class="mb-3 col col-6">
                                        <label for="manager_email<?php echo e($manager->id); ?>" class="form-label">Email <span class="text-danger"><sup>*</sup></span></label>
                                        <input type="email" class="form-control" id="manager_email<?php echo e($manager->id); ?>" name="manager_email" value="<?php echo e($manager->email); ?>">
                                    </div>
                                    <div class="mb-3 col col-6">
                                        <label for="manager_position<?php echo e($manager->id); ?>" class="form-label">Position</label>
                                        <input type="text" class="form-control" id="manager_position<?php echo e($manager->id); ?>" name="manager_position" value="<?php echo e($manager->relation); ?>">
                                        <small class="form-text text-muted">e.g., PA, Manager, Admin, etc.</small>
                                    </div>
                                </div>
                                <div class="modal-footer d-flex justify-content-center">
                                    <button type="submit" class="btn btn-success">Update</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    <script>


        document.getElementById('add_manager').addEventListener('click', function() {
            var managerInfoDiv = document.getElementById('manager_information');
            var managerFields = managerInfoDiv.querySelectorAll('input');
            const nomanagerdiv = document.getElementById('no_manager');

            managerInfoDiv.classList.remove('d-none');
            managerFields.forEach(function(input) {
                input.setAttribute('required', 'required');
            });

            nomanagerdiv.style.display = 'none';
        });


        document.querySelector('#manager_information .close').addEventListener('click', function() {
            var managerInfoDiv = document.getElementById('manager_information');
            var managerFields = managerInfoDiv.querySelectorAll('input');
            const nomanagerdiv = document.getElementById('no_manager');

            managerInfoDiv.classList.add('d-none');
            managerFields.forEach(function(input) {
                input.removeAttribute('required');
                input.value = '';
            });

            nomanagerdiv.style.display = 'block';
        });
    </script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var countrySelect = document.getElementById('country_id');
        var stateSelect = document.getElementById('state_id');
        var citySelect = document.getElementById('city_id');

        var customerCountryId = '<?php echo e(old("country_id", $customer->country_id)); ?>';
        var customerStateId = '<?php echo e(old("state_id", $customer->state_id)); ?>';
        var customerCityId = '<?php echo e(old("city_id", $customer->city_id)); ?>';

        // Function to fetch and populate states based on the selected country
        function fetchStates(countryId, callback) {
            fetch('/get-states/' + countryId)
                .then(function(response) {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(function(data) {
                    // Populate state dropdown with fetched states
                    stateSelect.innerHTML = '<option value="" selected disabled>Select State</option>';
                    data.forEach(function(state) {
                        var option = document.createElement('option');
                        option.value = state.id;
                        option.textContent = state.name;
                        stateSelect.appendChild(option);
                    });

                    // If there's a customer state, select it
                    if (customerStateId) {
                        stateSelect.value = customerStateId;
                        fetchCities(customerStateId); // Fetch cities for the selected state
                    }

                    if (callback) callback();
                })
                .catch(function(error) {
                    console.error('There was a problem with fetch operation:', error);
                });
        }

        // Function to fetch and populate cities based on the selected state
        function fetchCities(stateId) {
            fetch('/get-cities/' + stateId)
                .then(function(response) {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(function(data) {
                    // Populate city dropdown with fetched cities
                    citySelect.innerHTML = '<option value="" selected disabled>Select City</option>';
                    data.forEach(function(city) {
                        var option = document.createElement('option');
                        option.value = city.id;
                        option.textContent = city.name;
                        citySelect.appendChild(option);
                    });

                    // If there's a customer city, select it
                    if (customerCityId) {
                        citySelect.value = customerCityId;
                    }
                })
                .catch(function(error) {
                    console.error('There was a problem with fetch operation:', error);
                });
        }

        // Listen for changes to the country dropdown
        countrySelect.addEventListener('change', function() {
            var countryId = this.value;

            // Clear current state and city options
            stateSelect.innerHTML = '<option value="" selected disabled>Select State</option>';
            citySelect.innerHTML = '<option value="" selected disabled>Select City</option>';

            if (countryId) {
                fetchStates(countryId);
            }
        });

        // Listen for changes to the state dropdown
        stateSelect.addEventListener('change', function() {
            var stateId = this.value;

            // Clear current city options
            citySelect.innerHTML = '<option value="" selected disabled>Select City</option>';

            if (stateId) {
                fetchCities(stateId);
            }
        });

        // If a country is selected on page load, trigger the state fetching
        if (countrySelect.value) {
            fetchStates(countrySelect.value);
        }
    });
</script>


<script>
    const mobileInputField = document.querySelector("#mobile");
    const whatsappInputField = document.querySelector("#whatsapp");

    const mobileInput = window.intlTelInput(mobileInputField, {
        separateDialCode: true,
        preferredCountries: ["in", "us", "uk"],
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
    });

    const whatsappInput = window.intlTelInput(whatsappInputField, {
        separateDialCode: true,
        preferredCountries: ["in", "us", "uk"],
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/utils.js",
    });

    // Copy mobile number to WhatsApp field if it’s empty
    mobileInputField.addEventListener("input", () => {
        if (!whatsappInputField.value) {
            whatsappInput.setNumber(mobileInput.getNumber());
        }
    });

    document.getElementById("customerForm").addEventListener("submit", function(e) {
        if (mobileInput.isValidNumber()) {
            mobileInputField.value = mobileInput.getNumber();
        } else {
            e.preventDefault();
            alert("Please enter a valid mobile number.");
        }

        if (whatsappInputField.value && whatsappInput.isValidNumber()) {
            whatsappInputField.value = whatsappInput.getNumber();
        } else if (whatsappInputField.value) {
            e.preventDefault();
            alert("Please enter a valid WhatsApp number.");
        }
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4new\htdocs\nomads\resources\views/homecontent/customer/edit.blade.php ENDPATH**/ ?>