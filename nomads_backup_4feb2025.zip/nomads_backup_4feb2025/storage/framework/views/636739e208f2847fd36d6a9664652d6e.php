<?php $__env->startSection('title', 'Edit Employee'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">
        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Validation Errors -->
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <div class="text-right p-2">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm btn-primary">
                            Back</a>
                    </div>

                    <!-- Edit Employee Form -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Edit Employee Details</h6>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('employees.update', $employee->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="row">
                                    <!-- First Name -->
                                    <div class="form-group col-6">
                                        <label for="first_name">First Name</label>
                                        <input type="text" name="first_name" id="first_name" class="form-control"
                                            value="<?php echo e(old('first_name', $employee->first_name)); ?>" required>
                                    </div>

                                    <!-- Last Name -->
                                    <div class="form-group col-6">
                                        <label for="last_name">Last Name</label>
                                        <input type="text" name="last_name" id="last_name" class="form-control"
                                            value="<?php echo e(old('last_name', $employee->last_name)); ?>">
                                    </div>

                                    <!-- Mobile -->
                                    <div class="form-group col-6">
                                        <label for="mobile">Mobile</label>
                                        <input type="text" name="mobile" id="mobile" class="form-control"
                                            value="<?php echo e(old('mobile', $employee->mobile)); ?>" oninput="document.getElementById('whatsapp').value = this.value;">
                                    </div>

                                    <!-- WhatsApp -->
                                    <div class="form-group col-6">
                                        <label for="whatsapp">WhatsApp</label>
                                        <input type="text" name="whatsapp" id="whatsapp" class="form-control"
                                            value="<?php echo e(old('whatsapp', $employee->whatsapp)); ?>">
                                    </div>

                                    <!-- Email -->
                                    <div class="form-group col-6">
                                        <label for="email">Email</label>
                                        <input type="email" name="email" id="email" class="form-control"
                                            value="<?php echo e(old('email', $employee->email)); ?>">
                                    </div>

                                    <!-- Password -->
                                    <div class="form-group col-6">
                                        <label for="password">Password</label>
                                        <input type="password" name="password" id="password" class="form-control"
                                            placeholder="Leave blank to keep current password">
                                    </div>

                                    <!-- Department Dropdown -->
                                    

                                    <div class="mb-3 col col-6">
                                        <label for="departments" class="form-label">Departments <span class="text-danger">*</span></label>
                                        <select class="form-control" id="departments" name="departments[]" multiple="multiple" required>
                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($department->id); ?>"
                                                        <?php echo e(in_array($department->id, $employee->departments->pluck('id')->toArray()) ? 'selected' : ''); ?>>
                                                    <?php echo e($department->department_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <!-- Designation -->
                                    <div class="form-group col-6">
                                        <label for="designation_id">Designation</label>
                                        <select name="designation_id" id="designation_id" class="form-control">
                                            <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($designation->id); ?>"
                                                    <?php echo e(old('designation_id', $employee->designation_id) == $designation->id ? 'selected' : ''); ?>>
                                                    <?php echo e($designation->designation_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <!-- User Role -->
                                    <div class="form-group col-6">
                                        <label for="user_role_id">Employee Role</label>
                                        <select name="user_role_id" id="user_role_id" class="form-control">
                                            <?php $__currentLoopData = $userRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>"
                                                    <?php echo e(old('user_role_id', $employee->user_role_id) == $role->id ? 'selected' : ''); ?>>
                                                    <?php echo e($role->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <!-- Profile Image -->
                                    <!-- Profile Image -->
                                    <div class="form-group col-6">
                                        <label for="profile_image">Profile Image</label>

                                        <!-- Display the currently selected image -->
                                        <?php if($employee->profile_image): ?>
                                            <div class="mb-2">
                                                <strong>Current Image:</strong> <span
                                                    id="currentImageName"><?php echo e(basename($employee->profile_image)); ?></span>
                                            </div>
                                            <div class="mb-2">
                                                <img src="<?php echo e(asset($employee->profile_image)); ?>" alt="Profile Image"
                                                    id="currentImagePreview" class="img-thumbnail" width="150">
                                            </div>
                                        <?php endif; ?>

                                        <input type="file" name="profile_image" id="profile_image"
                                            class="form-control" onchange="displaySelectedImageNameAndPreview()">
                                    </div>

                                    <script>
                                        function displaySelectedImageNameAndPreview() {
                                            var input = document.getElementById('profile_image');
                                            var currentImageName = document.getElementById('currentImageName');
                                            var currentImagePreview = document.getElementById('currentImagePreview');

                                            if (input.files && input.files.length > 0) {
                                                currentImageName.innerHTML = input.files[0].name;

                                                // Display the new image preview
                                                var reader = new FileReader();
                                                reader.onload = function(e) {
                                                    currentImagePreview.src = e.target.result;
                                                }
                                                reader.readAsDataURL(input.files[0]);
                                            }
                                        }
                                    </script>

                                    <!-- Permissions -->
                                    <!-- Permissions -->
                                    <div class="form-group col col-6">
                                        <label for="permissions">Permissions</label>
                                        <div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="add" id="permissionAdd"
                                                    <?php echo e(isset($permissions) && $permissions->add ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="permissionAdd">
                                                    Add
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="view" id="permissionView"
                                                    <?php echo e(isset($permissions) && $permissions->view ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="permissionView">
                                                    View
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="edit" id="permissionEdit"
                                                    <?php echo e(isset($permissions) && $permissions->edit ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="permissionEdit">
                                                    Edit
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="update" id="permissionUpdate"
                                                    <?php echo e(isset($permissions) && $permissions->update ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="permissionUpdate">
                                                    Update
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="permissions[]" value="delete" id="permissionDelete"
                                                    <?php echo e(isset($permissions) && $permissions->delete ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="permissionDelete">
                                                    Delete
                                                </label>
                                            </div>
                                        </div>
                                    </div>





                                    <!-- Miscellaneous -->
                                    <div class="form-group col-6">
                                        <label for="miscellaneous">Miscellaneous</label>
                                        <textarea name="miscellaneous" id="miscellaneous" class="form-control"><?php echo e(old('miscellaneous', $employee->miscellaneous)); ?></textarea>
                                    </div>

                                    <!-- Is Active -->
                                    <div class="form-group col col-6">
                                        <label for="is_active" style="font-weight:bold;">Is Active</label>
                                        <input type="checkbox" name="is_active" id="is_active" value="1"
                                            <?php echo e($employee->is_active ? 'checked' : ''); ?>>
                                    </div>

                                </div>


                                <!-- Submit Button -->
                                <button type="submit" class="btn btn-primary">Update</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script>
        // $(document).ready(function() {
        //     // Function to update the selected departments display
        //     function updateSelectedDepartments() {
        //         let selectedDepartments = [];
        //         $("input[name='departments[]']:checked").each(function() {
        //             selectedDepartments.push($(this).next('label').text());
        //         });
        //         $('#selectedDepartments').html(selectedDepartments.join(', '));
        //     }

        //     // Event listener for checkbox changes
        //     $("input[name='departments[]']").change(function() {
        //         updateSelectedDepartments();
        //     });

        //     // Initial update on page load
        //     updateSelectedDepartments();
        // });

        $(document).ready(function() {
                $('#departments').select2({
                    placeholder: 'Select department(s)',
                    allowClear: true,
                    width: '100%'
                });

            });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4new\htdocs\nomads\resources\views/homecontent/employee/edit.blade.php ENDPATH**/ ?>