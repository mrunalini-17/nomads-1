<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    
                    <div class="py-3 px-2">
                        <h3 class="font-weight-bold text-primary">Customer List</h3>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        
                        <div class="card-body">
                            <div class="text-right mb-3"><a class="btn btn-sm btn-primary" href="<?php echo e(route('customers.create')); ?>">Add Customer</a></div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped" id="dataTable" cellspacing="0">
                                       <thead class="bg-light text-dark">
                                        <tr>
                                            <th>Sr no</th>
                                            <th>Name</th>
                                            <th>Mobile</th>
                                            <th>Whatsapp</th>
                                            <th>Email</th>
                                            <th>Address</th>
                                            <th>Reference</th>
                                            <th>Has Manager</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $address = implode(', ', array_filter([
                                                    $customer->locality,
                                                    optional($customer->city)->name,
                                                    optional($customer->state)->name,
                                                    optional($customer->country)->name,
                                                    $customer->pincode,
                                                ]));
                                            ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($customer->fname); ?> <?php echo e($customer->lname); ?></td>
                                                <td><?php echo e($customer->mobile); ?></td>
                                                <td><?php echo e($customer->whatsapp); ?></td>
                                                <td><?php echo e($customer->email); ?></td>
                                                <td><?php echo e($address); ?></td>
                                                <td><?php echo e($customer->reference->name ?? 'N.A.'); ?></td>
                                                <td><?php echo e($customer->have_manager ? 'Yes' : 'No'); ?></td>
                                                <td>
                                                    <div class="text-center">
                                                        <!-- Dropdown button -->
                                                        <div class="dropdown">
                                                            <button class="text-info border-0 bg-transparent dropdown-toggle" type="button" id="dropdownMenuButton<?php echo e($customer->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                                <i class="fa-solid fa-ellipsis-vertical"></i>
                                                            </button>
                                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?php echo e($customer->id); ?>">
                                                                <li>
                                                                    <a class="dropdown-item text-success"  href="<?php echo e(route('customers.show', $customer->id)); ?>">
                                                                        <i class="fa-solid fa-eye"></i> View
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <a class="dropdown-item text-primary" href="<?php echo e(route('customers.edit', $customer->id)); ?>">
                                                                        <i class="fa-solid fa-pen-to-square"></i> Edit
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <form action="<?php echo e(route('customers.destroy', $customer->id)); ?>" method="POST" style="display:inline;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button class="dropdown-item text-danger" onclick="return confirm('Are you sure you want to delete this customer?');">
                                                                            <i class="fa-solid fa-trash"></i> Delete
                                                                        </button>
                                                                    </form>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!-- Modal -->
    <div class="modal fade" id="viewModal<?php echo e($customer->id); ?>" tabindex="-1" aria-labelledby="viewModalLabel<?php echo e($customer->id); ?>" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewModalLabel<?php echo e($customer->id); ?>">Customer Details</h5>
                      <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body">
                    <table class="table table-striped">
                        <tr>
                            <th>Name</th>
                            <td><?php echo e($customer->name); ?></td>
                        </tr>
                        <tr>
                            <th>Mobile</th>
                            <td><?php echo e($customer->mobile); ?></td>
                        </tr>
                        <tr>
                            <th>WhatsApp</th>
                            <td><?php echo e($customer->whatsapp); ?></td>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <td><?php echo e($customer->email); ?></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?php echo e($customer->address); ?></td>
                        </tr>
                        <tr>
                            <th>Service</th>
                            <td><?php echo e($customer->service->service_name ?? 'NA'); ?></td>
                        </tr>
                        <tr>
                            <th>Has Manager</th>
                            <td><?php echo e($customer->have_manager ? 'Yes' : 'No'); ?></td>
                        </tr>
                        <?php if($customer->have_manager): ?>
                            <tr>
                                <th>Manager Name</th>
                                <td><?php echo e($customer->manager_name ?? 'NA'); ?></td>
                            </tr>
                            <tr>
                                <th>Manager Mobile</th>
                                <td><?php echo e($customer->manager_mobile ?? 'NA'); ?></td>
                            </tr>
                            <tr>
                                <th>Manager WhatsApp</th>
                                <td><?php echo e($customer->manager_whatsapp ?? 'NA'); ?></td>
                            </tr>
                            <tr>
                                <th>Manager Email</th>
                                <td><?php echo e($customer->manager_email ?? 'NA'); ?></td>
                            </tr>
                            <tr>
                                <th>Manager Position</th>
                                <td><?php echo e($customer->manager_position ?? 'NA'); ?></td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <th>Added By</th>
                            <td><?php echo e(optional($customer->addedBy)->first_name ?? 'NA'); ?> <?php echo e(optional($customer->addedBy)->last_name ?? ''); ?></td>
                        </tr>
                        <tr>
                            <th>Updated By</th>
                            <td><?php echo e(optional($customer->updatedBy)->first_name ?? 'NA'); ?> <?php echo e(optional($customer->updatedBy)->last_name ?? ''); ?></td>
                        </tr>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- End Modal -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4new\htdocs\nomads\resources\views/homecontent/customer/index.blade.php ENDPATH**/ ?>