<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nomads Holidays: Booking Confirmation</title>
</head>
<body>
    <div class="container" style="font-family: Arial, sans-serif; line-height: 1.6; max-width: 800px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; background-color: #f2e8de;">
        <div style="text-align: center; margin-bottom: 20px;">
            <!-- SVG Logo -->
            

            <!-- Company Name -->
            <h2 style="margin: 10px 0; color: #333;">Nomads Holidays</h2>
        </div>

        <h2 style="color: #333; text-align: center;">Booking Confirmation</h2>


        <h4>Hello <?php echo e($booking->customer->fname); ?> <?php echo e($booking->customer->lname); ?>,</h4>

        <p>Your booking with Nomads Holidays is confirmed! 🎉 Below are the details:</p>

        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
            <tr>
                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Guest Name</th>
                <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;"><?php echo e($booking->customer->fname); ?> <?php echo e($booking->customer->lname); ?></td>
                
                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Booking Date</th>
                <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;"><?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('d M, Y')); ?></td>
            </tr>

                <?php
                    $amount_shareable = $booking->amount_shareable;
                    $grossAmount = $booking->bookingServices->sum('gross_amount');
                    $clientRemark = $booking->bookingRemarks->firstWhere('remark_type', 'client');
                ?>
            <?php if($amount_shareable): ?>
                <tr>
                    <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Total Amount</th>
                    <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;"><?php echo e(number_format($grossAmount, 2)); ?> <?php echo e($booking->currency); ?></td>
                    <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Total Guests</th>
                    <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;"><?php echo e($booking->passenger_count); ?></td>
                </tr>
                <tr>


                    <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Remarks</th>
                    <?php if(optional($clientRemark)->is_shareable): ?>
                        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;">
                            <?php echo e($clientRemark->description ?? 'N/A'); ?>

                        </td>
                    <?php else: ?>
                        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;">N/A</td>
                    <?php endif; ?>
                </tr>
            <?php else: ?>
                <tr>
                    <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Total Guests</th>
                    <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;"><?php echo e($booking->passenger_count); ?></td>

                    <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Special Requests</th>
                    <?php if(optional($clientRemark)->is_shareable): ?>
                        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;">
                            <?php echo e($clientRemark->description ?? 'N/A'); ?>

                        </td>
                    <?php else: ?>
                        <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;">N/A</td>
                    <?php endif; ?>


                </tr>
            <?php endif; ?>

        </table>

        <h4 style="text-align: left; margin: 20px 0;">Service Details</h4>
        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
            <tr>
                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Service</th>
                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Travel Date 1</th>
                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">Travel Date 2</th>
                <th style="text-align: left; padding: 8px; border: 1px solid #ddd;">PNR</th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $booking->bookingServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;"><?php echo e($service->service_details ?? 'N/A'); ?></td>
                <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;">
                    <?php echo e($service->travel_date1 ? \Carbon\Carbon::parse($service->travel_date1)->format('d-m-Y') : 'N/A'); ?>

                </td>
                <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;">
                    <?php echo e($service->travel_date2 ? \Carbon\Carbon::parse($service->travel_date2)->format('d-m-Y') : 'N/A'); ?>

                </td>
                <td style="padding: 8px; border: 1px solid #ddd; background-color: #f8f8f8;"><?php echo e($service->confirmation_number ?? 'N/A'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" style="padding: 8px; border: 1px solid #ddd; text-align: center;">No services available</td>
            </tr>
            <?php endif; ?>
        </table>

        <p><strong>Processed by : </strong> <?php echo e($booking->addedBy->first_name ?? '--'); ?> <?php echo e($booking->addedBy->last_name ?? '--'); ?> (<?php echo e($booking->addedBy->mobile ?? '--'); ?>)</p>

        <p>If there are any discrepancies in the above details, please contact our team or reach us at our Emergency Number: +91 8408803000</p>

        <p>We look forward to making your trip memorable!</p>

        <div style="margin-top: 20px; text-align: left;">
            <p>Warm regards,</p>
            <p><strong>Nomads Holidays</strong></p>
        </div>

        <footer style="margin-top: 30px; text-align: center; color: #888;">
            <p style="font-size: 12px;">Nomads Holidays, All rights reserved.</p>
            <p style="font-size: 12px;">This is an automated email. Please do not reply to this message.</p>
        </footer>
    </div>
</body>
</html>
<?php /**PATH C:\xampp8.2.4new\htdocs\nomads\resources\views/emails/booking_confirmation_mail_client.blade.php ENDPATH**/ ?>