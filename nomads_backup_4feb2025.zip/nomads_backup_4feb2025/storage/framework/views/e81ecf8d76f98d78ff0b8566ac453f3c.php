<?php $__env->startSection('title', 'Employee Details'); ?>

<style>
    .table {
        table-layout: fixed;
        width: 100%;
    }

    .table th,
    .table td {
        width: 25%;
        word-wrap: break-word;
    }

    .badge {
        display: inline-block;
        margin: 2px;
    }
</style>


<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">
        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <!-- Validation Errors -->
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="text-right p-2">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm btn-primary">
                             Back
                        </a>
                    </div>

                    <!-- Employee Details Card -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Employee Details</h6>
                        </div>
                        <div class="card-body text-center">
                            <!-- Profile Image -->
                            <div class="mb-4">
                                <img src="<?php echo e(asset($employee->profile_image)); ?>"
                                    class="rounded-circle img-fluid" alt="<?php echo e($employee->first_name . ' ' . $employee->last_name); ?>"
                                    style="width: 150px; height: 150px;">
                            </div>

                            <!-- Employee Details in Table -->
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <tbody>
                                        <!-- Row 1 -->
                                        <tr>
                                            <th>First Name</th>
                                            <td><?php echo e($employee->first_name ?? 'N/A'); ?></td>
                                            <th>Last Name</th>
                                            <td><?php echo e($employee->last_name ?? 'N/A'); ?></td>
                                        </tr>

                                        <!-- Row 2 -->
                                        <tr>
                                            <th>Mobile</th>
                                            <td><?php echo e($employee->mobile ?? 'N/A'); ?></td>
                                            <th>WhatsApp</th>
                                            <td><?php echo e($employee->whatsapp ?? 'N/A'); ?></td>
                                        </tr>

                                        <!-- Row 3 -->
                                        <tr>
                                            <th>Email</th>
                                            <td><?php echo e($employee->email ?? 'N/A'); ?></td>
                                            <th>Departments</th>
                                            <td>
                                                <?php if($employee->departments->isEmpty()): ?>
                                                    N/A
                                                <?php else: ?>
                                                    <?php $__currentLoopData = $employee->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <span class="badge badge-primary"><?php echo e($department->department_name); ?></span>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </td>
                                        </tr>

                                        <!-- Row 4 -->
                                        <tr>
                                            <th>Designation</th>
                                            <td><?php echo e($employee->designation->designation_name ?? 'N/A'); ?></td>
                                            <th>Employee Role</th>
                                            <td><?php echo e($employee->userRole->name ?? 'N/A'); ?></td>
                                        </tr>

                                        <!-- Row 5 -->
                                        <tr>
                                            <th>Miscellaneous</th>
                                            <td colspan="3"><?php echo e($employee->miscellaneous ?? 'N/A'); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/employee/show.blade.php ENDPATH**/ ?>