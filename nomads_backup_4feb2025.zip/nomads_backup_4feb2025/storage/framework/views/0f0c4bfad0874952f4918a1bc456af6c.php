<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="py-3 px-2">
                        <h3 class="font-weight-bold text-primary">View Enquiry</h3>
                    </div>
                    <div class="text-right p-2">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm btn-primary"> Back </a>
                    </div>

                    <!-- Booking Details -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h5 class="m-0">Enquiry Information</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped">
                                <tbody>
                                    <tr>
                                        <td><strong>Customer</strong> </td>
                                        <td> <?php echo e($enquiry->fname ?? 'N/A'); ?> <?php echo e($enquiry->lname ?? ''); ?></td>

                                        <td><strong>Date</strong></td>
                                        <td> <?php echo e(\Carbon\Carbon::parse($enquiry->created_at)->format('d-m-Y')); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Mobile</strong></td>
                                        <td> <?php echo e($enquiry->mobile ?? '--'); ?></td>

                                        <td><strong>Whatsapp</strong></td>
                                        <td> <?php echo e($enquiry->whatsapp ?? '--'); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Email</strong></td>
                                        <td> <?php echo e($enquiry->email ?? '--'); ?></td>
                                        <td><strong>Address</strong></td>
                                        <td> <?php echo e($enquiry->address ?? '--'); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Priority</strong></td>
                                        <td> <?php echo e(ucfirst($enquiry->priority)); ?></td>
                                        <td><strong>Service</strong></td>
                                        <td>
                                            <?php $__currentLoopData = $enquiry->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($service->name); ?><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Status</strong></td>
                                        <td> <?php echo e(ucfirst($enquiry->status)); ?></td>
                                        <td><strong>Notes:</strong></td>
                                        <td> <?php echo e($enquiry->note); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong>Assigned To</strong></td>
                                        <td>
                                            <?php if($employees->isNotEmpty()): ?>
                                                <?php echo e($employees->map(function($employee) {
                                                    return $employee->first_name . ' ' . $employee->last_name;
                                                })->join(', ')); ?>

                                            <?php else: ?>
                                                Not assigned
                                            <?php endif; ?>
                                        </td>
                                        <td><strong>Accepted By</strong></td>
                                        <td class="text-primary"> <?php echo e(optional($enquiry->acceptedBy)->first_name . ' ' . optional($enquiry->acceptedBy)->last_name); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Remarks -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h5 class="m-0">Remarks</h5>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Remark Type</th>
                                        <th>Remark</th></th>
                                        <th>Date</th>
                                        <th>Time</th>
                                        <th>Shared</th>
                                        <th>Added by</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $enquiry->enquiryRemarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e(ucfirst($remark->remark_type)); ?></td>
                                            <td><?php echo e($remark->description ?? 'N/A'); ?></td>
                                            <td><?php echo e($remark->created_at->format('d/m/Y')); ?></td> <!-- Format Date -->
                                            <td><?php echo e($remark->created_at->format('H:i')); ?></td>
                                            <td><?php echo e($remark->email_sent ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($remark->addedBy->first_name ?? 'N/A'); ?> <?php echo e($remark->addedBy->last_name ?? 'N/A'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-muted text-center">No remarks available.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>

                            </table>
                        </div>
                    </div>

                    <!-- Add Remarks -->
                    <div class="card mb-4 shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h5 class="m-0">Add Remarks</h5>
                        </div>
                        <form action="<?php echo e(route('new_enquiry.accept', $enquiry->id)); ?>" id="add_remarks_form" method="POST">
                        <div class="card-body">

                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div id="remarksContainer" class="col-12 col-md-12">
                                        <div class="remark-group row col-12 col-md-12" id="remark_group_1">
                                            <div class="mb-3 col col-3">
                                                <label for="remark_type_1" class="form-label">Remark Type <span class="text-danger">*</span></label>
                                                <select name="remark_type[]" id="remark_type_1" class="form-select form-control" required>
                                                    <option value="" disabled>Select</option>
                                                    <option value="office">Office</option>
                                                    <option value="client">Client</option>
                                                </select>
                                                <?php $__errorArgs = ['remark_type.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="mb-3 col col-8">
                                                <label for="remark_1" class="form-label">Remark <span class="text-danger">*</span></label>
                                                <textarea name="remark[]" id="remark_1" cols="" rows="" class="form-control"></textarea>
                                                <?php $__errorArgs = ['remark.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="col-1 text-right mt-4">
                                                <button type="button" class="btn btn-danger btn-sm btn-remove" data-id="1"><i class="fas fa-trash"></i></button>
                                            </div>

                                        </div>

                                    </div>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <button type="button" id="addRemarkBtn" class="btn btn-sm btn-success">Add More Remark</button>
                                </div>

                        </div>
                        <?php if(!$enquiry->is_accepted): ?>
                        <div class="card-footer d-flex justify-content-center">
                            <input type="hidden" name="update" value="0">
                            <button type="button" id="accept_button" class="btn btn-success accepted" data-enquiry-id="<?php echo e($enquiry->id); ?>">Accept</button>
                        </div>
                        <?php else: ?>
                        <div class="card-footer d-flex justify-content-center">
                            <input type="hidden" name="update" value="1">
                            <button type="button" id="update_button" class="btn btn-primary update" data-enquiry-id="<?php echo e($enquiry->id); ?>">Update</button>
                        </div>
                        <?php endif; ?>
                    </form>
                    </div>

                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>



<script>
    // Add More Remarks functionality
    let remarkCount = 1;

    document.getElementById('addRemarkBtn').addEventListener('click', function() {
        remarkCount++;

        // Create a new Remark Group (Remark Type + Remark + Delete Button)
        const newRemarkGroup = document.createElement('div');
        newRemarkGroup.className = 'remark-group row col-12 col-md-12';
        newRemarkGroup.id = `remark_group_${remarkCount}`;

        newRemarkGroup.innerHTML = `
            <div class="mb-3 col col-3">
                <label for="remark_type_${remarkCount}" class="form-label">Remark Type</label>
                <select name="remark_type[]" id="remark_type_${remarkCount}" class="form-select form-control" required>
                    <option value="" disabled>Select</option>
                    <option value="client">Client</option>
                    <option value="office">Office</option>
                </select>
            </div>
            <div class="mb-3 col col-8">
                <label for="remark_${remarkCount}" class="form-label">Remark</label>
                <textarea name="remark[]" id="remark_${remarkCount}" cols="" rows="" class="form-control"></textarea>
            </div>
            <div class="col-1 text-right mt-4">
                <button type="button" class="btn btn-danger btn-sm btn-remove" data-id="${remarkCount}"><i class="fas fa-trash"></i></button>
            </div>
        `;

        // Append new remark group to the container
        document.getElementById('remarksContainer').appendChild(newRemarkGroup);

        // Attach the delete functionality to the newly added remove button
        document.querySelector(`#remark_group_${remarkCount} .btn-remove`).addEventListener('click', function() {
            const groupId = this.getAttribute('data-id');
            document.getElementById(`remark_group_${groupId}`).remove();
        });
    });

    // Attach delete functionality to any existing delete button if needed
    document.querySelectorAll('.btn-remove').forEach(button => {
        button.addEventListener('click', function() {
            const groupId = this.getAttribute('data-id');
            document.getElementById(`remark_group_${groupId}`).remove();
        });
    });
    </script>

    <script>
        //accept the enquiry
        document.getElementById('accept_button').addEventListener('click', function(e) {
            e.preventDefault(); // Prevent form submission

            let isValid = true;

            // Loop through all the remark groups to validate inputs
            document.querySelectorAll('.remark-group').forEach(function(group) {
                const remarkType = group.querySelector('select[name="remark_type[]"]');
                const remark = group.querySelector('textarea[name="remark[]"]');

                // Clear previous error messages
                remarkType.classList.remove('is-invalid');
                remark.classList.remove('is-invalid');
                group.querySelectorAll('.invalid-feedback').forEach(el => el.remove());

                // Validate Remark Type
                if (!remarkType.value) {
                    isValid = false;
                    remarkType.classList.add('is-invalid');
                    const error = document.createElement('div');
                    error.className = 'invalid-feedback';
                    error.innerText = 'Please select a remark type.';
                    remarkType.parentNode.appendChild(error);
                }

                // Validate Remark Description
                if (!remark.value.trim()) {
                    isValid = false;
                    remark.classList.add('is-invalid');
                    const error = document.createElement('div');
                    error.className = 'invalid-feedback';
                    error.innerText = 'Please enter a remark.';
                    remark.parentNode.appendChild(error);
                }
            });

            if (isValid) {
                // If validation passes, submit the form
                document.getElementById('add_remarks_form').submit();
            }
        });

    </script>

<script>
    //accept the enquiry
    document.getElementById('update_button').addEventListener('click', function(e) {
        e.preventDefault(); // Prevent form submission

        let isValid = true;

        // Loop through all the remark groups to validate inputs
        document.querySelectorAll('.remark-group').forEach(function(group) {
            const remarkType = group.querySelector('select[name="remark_type[]"]');
            const remark = group.querySelector('textarea[name="remark[]"]');

            // Clear previous error messages
            remarkType.classList.remove('is-invalid');
            remark.classList.remove('is-invalid');
            group.querySelectorAll('.invalid-feedback').forEach(el => el.remove());

            // Validate Remark Type
            if (!remarkType.value) {
                isValid = false;
                remarkType.classList.add('is-invalid');
                const error = document.createElement('div');
                error.className = 'invalid-feedback';
                error.innerText = 'Please select a remark type.';
                remarkType.parentNode.appendChild(error);
            }

            // Validate Remark Description
            if (!remark.value.trim()) {
                isValid = false;
                remark.classList.add('is-invalid');
                const error = document.createElement('div');
                error.className = 'invalid-feedback';
                error.innerText = 'Please enter a remark.';
                remark.parentNode.appendChild(error);
            }
        });

        if (isValid) {
            // If validation passes, submit the form
            document.getElementById('add_remarks_form').submit();
        }
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/enquirie/edit_accepted.blade.php ENDPATH**/ ?>