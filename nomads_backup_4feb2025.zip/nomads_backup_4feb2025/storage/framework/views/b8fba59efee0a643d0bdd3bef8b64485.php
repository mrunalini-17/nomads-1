<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    
                    <div class="py-3 px-2">
                        <h3 class="font-weight-bold text-primary">Employee List</h3>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">

                        <div class="card-body">
                            <div class="text-right mb-3"><a class="btn btn-sm btn-primary"
                                    href="<?php echo e(route('employees.create')); ?>">Add Employee</a></div>
                            <table class="table table-bordered table-striped" id="dataTable" cellspacing="0">
                                <thead class="bg-light text-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile Number</th>
                                        <th>Role</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($employee->first_name && $employee->last_name ? $employee->first_name . ' ' . $employee->last_name : 'N/A'); ?>

                                            </td>
                                            <td><?php echo e($employee->email ?: 'N/A'); ?></td>
                                            <td><?php echo e($employee->mobile ?: 'N/A'); ?></td>
                                            <td><?php echo e($employee->userRole ? $employee->userRole->name : 'N/A'); ?></td>
                                            <td>
                                                <div class="text-center">
                                                    <!-- Dropdown button -->
                                                    <div class="dropdown">
                                                        <button class="text-info border-0 bg-transparent dropdown-toggle"
                                                            type="button" id="dropdownMenuButton<?php echo e($employee->id); ?>"
                                                            data-bs-toggle="dropdown" aria-expanded="false">
                                                            <i class="fa-solid fa-ellipsis-vertical"></i>
                                                        </button>
                                                        <ul class="dropdown-menu"
                                                            aria-labelledby="dropdownMenuButton<?php echo e($employee->id); ?>">
                                                            <li>
                                                                <a class="dropdown-item text-success"
                                                                    href="<?php echo e(route('employees.show', $employee->id)); ?>">
                                                                    <i class="fa-solid fa-eye"></i> View
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a class="dropdown-item text-warning"
                                                                    href="<?php echo e(route('employees.edit', $employee->id)); ?>">
                                                                    <i class="fa-solid fa-pen-to-square"></i> Edit
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <a class="dropdown-item text-primary" data-bs-toggle="modal"
                                                                    data-bs-target="#changePasswordModal<?php echo e($employee->id); ?>">
                                                                    <i class="fa-solid fa-key"></i> Change Password
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <form
                                                                    action="<?php echo e(route('employees.destroy', $employee->id)); ?>"
                                                                    method="POST" style="display:inline;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button class="dropdown-item text-danger"
                                                                        onclick="return confirm('Are you sure you want to delete this employee?');">
                                                                        <i class="fa-solid fa-trash"></i> Delete
                                                                    </button>
                                                                </form>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <!-- Change Password Modal -->
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="modal fade" id="changePasswordModal<?php echo e($employee->id); ?>" tabindex="-1"
                                    aria-labelledby="changePasswordModalLabel<?php echo e($employee->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6 class="modal-title m-0 font-weight-bold text-primary"
                                                    id="changePasswordModalLabel<?php echo e($employee->id); ?>">Change Password</h6>
                                                <button type="button" class="close" data-bs-dismiss="modal"
                                                    aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <form action="<?php echo e(route('employees.updatePassword', $employee->id)); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <div class="row">
                                                        <!-- New Password Field -->
                                                        <div class="mb-3 col-12">
                                                            <label for="newPassword<?php echo e($employee->id); ?>"
                                                                class="form-label">New Password</label>
                                                            <div class="input-group">
                                                                <input type="password" class="form-control"
                                                                    id="newPassword<?php echo e($employee->id); ?>" name="password"
                                                                    required>
                                                                <div class="input-group-append">
                                                                    <button class="btn btn-outline-secondary" type="button"
                                                                        id="toggleNewPassword<?php echo e($employee->id); ?>">
                                                                        <i class="fa fa-eye"
                                                                            id="eyeIconNew<?php echo e($employee->id); ?>"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Confirm New Password Field -->
                                                        <div class="mb-3 col-12">
                                                            <label for="confirmPassword<?php echo e($employee->id); ?>"
                                                                class="form-label">Confirm New Password</label>
                                                            <div class="input-group">
                                                                <input type="password" class="form-control"
                                                                    id="confirmPassword<?php echo e($employee->id); ?>"
                                                                    name="password_confirmation" required>
                                                                <div class="input-group-append">
                                                                    <button class="btn btn-outline-secondary" type="button"
                                                                        id="toggleConfirmPassword<?php echo e($employee->id); ?>">
                                                                        <i class="fa fa-eye"
                                                                            id="eyeIconConfirm<?php echo e($employee->id); ?>"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-success">Save changes</button>
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>
                                                    </div>
                                                </form>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </div>
                    </div>
                </div>
            </div>
              <!-- Footer -->
    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of Footer -->

        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->



    </div>
    <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle visibility for new password
            document.querySelectorAll('[id^="toggleNewPassword"]').forEach(button => {
                button.addEventListener('click', function() {
                    const passwordField = document.querySelector(
                        `#${this.id.replace('toggleNewPassword', 'newPassword')}`);
                    const eyeIcon = document.querySelector(
                        `#${this.id.replace('toggleNewPassword', 'eyeIconNew')}`);

                    if (passwordField.type === 'password') {
                        passwordField.type = 'text';
                        eyeIcon.classList.remove('fa-eye');
                        eyeIcon.classList.add('fa-eye-slash');
                    } else {
                        passwordField.type = 'password';
                        eyeIcon.classList.remove('fa-eye-slash');
                        eyeIcon.classList.add('fa-eye');
                    }
                });
            });

            // Toggle visibility for confirm password
            document.querySelectorAll('[id^="toggleConfirmPassword"]').forEach(button => {
                button.addEventListener('click', function() {
                    const passwordField = document.querySelector(
                        `#${this.id.replace('toggleConfirmPassword', 'confirmPassword')}`);
                    const eyeIcon = document.querySelector(
                        `#${this.id.replace('toggleConfirmPassword', 'eyeIconConfirm')}`);

                    if (passwordField.type === 'password') {
                        passwordField.type = 'text';
                        eyeIcon.classList.remove('fa-eye');
                        eyeIcon.classList.add('fa-eye-slash');
                    } else {
                        passwordField.type = 'password';
                        eyeIcon.classList.remove('fa-eye-slash');
                        eyeIcon.classList.add('fa-eye');
                    }
                });
            });
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/employee/index.blade.php ENDPATH**/ ?>