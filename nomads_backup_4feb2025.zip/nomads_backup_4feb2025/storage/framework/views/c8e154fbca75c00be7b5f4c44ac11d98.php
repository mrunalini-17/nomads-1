<?php $__env->startSection('title', 'Booking Details'); ?>

<style>
    .highlight {
    background-color: #ecd0d8; /* Highlight color */
}

</style>
<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->



        <!-- Content Wrapper -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="py-3 px-2">
                <h3 class="font-weight-bold text-primary">Booking Details</h3>
            </div>

            <!-- Back Button -->
            <div class="text-right mb-3">
                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm btn-primary">
                     Back
                </a>
            </div>

            <!-- Booking Details -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="m-0">ID : <?php echo e($booking->unique_code); ?></h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <td><strong>Customer:</strong> <?php echo e($booking->customer->fname ?? 'N/A'); ?>

                                    <?php echo e($booking->customer->lname ?? ''); ?></td>
                                <td><strong>Customer Manager:</strong> <?php echo e($booking->customerManager->fname ?? 'N/A'); ?>

                                    <?php echo e($booking->customerManager->lname ?? ''); ?></td>
                                <td><strong>Booking Date:</strong> <?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('d-m-Y')); ?></td>

                                <td><strong>Passenger Count:</strong> <?php echo e($booking->passenger_count ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Service:</strong> <?php echo e($booking->service->name ?? 'N/A'); ?></td>
                                <td><strong>Status:</strong> <?php echo e($booking->status ?? 'N/A'); ?></td>
                                <td><strong>Bill To:</strong>
                                    <?php if($booking->bill_to === 'self' || $booking->bill_to === 'other'): ?>
                                        <?php echo e($booking->bill_to_remark ?? 'N/A'); ?>

                                    <?php elseif($booking->bill_to === 'company' && $booking->company): ?>
                                        <div>
                                            <strong>Company Name:</strong> <?php echo e($booking->company->name ?? 'N/A'); ?><br>
                                            <strong>Mobile:</strong> <?php echo e($booking->company->mobile ?? 'N/A'); ?><br>
                                            <strong>GST:</strong> <?php echo e($booking->company->gst ?? 'N/A'); ?><br>
                                            <strong>Address:</strong> <?php echo e($booking->company->address ?? 'N/A'); ?>

                                        </div>
                                    <?php else: ?>
                                        <?php echo e($booking->bill_to ?? 'N/A'); ?>

                                    <?php endif; ?>
                                </td>
                                <td><strong>PAN Number:</strong> <?php echo e($booking->pan_number ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Invoice Number:</strong> <?php echo e($booking->invoice_number ?? 'N/A'); ?></td>
                                <td><strong>Payment Status:</strong> <?php echo e($booking->payment_status ?? 'N/A'); ?></td>
                                <td><strong>Payment Received Remark:</strong>
                                    <?php echo e($booking->payment_received_remark ?? 'N/A'); ?></td>
                                <td><strong>Office Reminder:</strong> <?php echo e($booking->office_reminder ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td colspan="4"><strong>Cancelled:</strong> <?php echo e($booking->is_cancelled ? 'Yes' : 'No'); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>


            <?php if($booking->is_cancelled && $cancellation): ?>
            <!-- Cancellation Details -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="m-0">Cancellation Details</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <tbody>
                            <tr>
                                <td><strong>Reason:</strong> <?php echo e($cancellation->reason ?? 'N/A'); ?></td>
                                <td><strong>Cancellation Charges:</strong> <?php echo e($cancellation->charges ?? 'N/A'); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Details:</strong> <?php echo e($cancellation->details ?? 'N/A'); ?></td>
                                <td><strong>Charges Received:</strong>
                                    <?php if(is_null($cancellation->charges_received)): ?>
                                        N/A
                                    <?php elseif($cancellation->charges_received): ?>
                                        Yes
                                    <?php else: ?>
                                        No
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <!-- Passenger Information -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="m-0">Passenger Information</h5>
                </div>
                <div class="card-body">
                    <?php if($booking->passengerCounts->isNotEmpty()): ?>
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    
                                    <th>Gender</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $booking->passengerCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($passenger->name ?? 'N/A'); ?></td>
                                        
                                        <td><?php echo e($passenger->gender ?? 'N/A'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p class="text-muted">No passenger information available.</p>
                    <?php endif; ?>
                </div>
            </div>


            <!-- Service Details -->
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5 class="m-0">Service Details</h5>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $booking->bookingServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="mb-4">
                            <h6>
                                <strong>Service <?php echo e($index + 1); ?>:</strong>
                                <?php if(is_null($service->updates)): ?>
                                    <strong style="color:green;">Old</strong>
                                <?php else: ?>
                                    <strong style="color:red;">Revised</strong>
                                <?php endif; ?>
                            </h6>

                            <table class="table table-bordered table-striped">
                                <tbody>
                                    <?php
                                        $updates = json_decode($service->updates, true) ?? [];
                                    ?>
                                    <tr>
                                        <td class="<?php echo e(in_array('service_details', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Service Details:</strong> <?php echo e($service->service_details ?? 'N/A'); ?>

                                        </td>
                                        <td class="<?php echo e(in_array('travel_date1', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Travel Date 1:</strong> <?php echo e($service->travel_date1 ? \Carbon\Carbon::parse($service->travel_date1)->format('d-m-Y') : 'N/A'); ?>

                                        </td>
                                        <td class="<?php echo e(in_array('travel_date2', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Travel Date 2:</strong> <?php echo e($service->travel_date2 ? \Carbon\Carbon::parse($service->travel_date2)->format('d-m-Y') : 'N/A'); ?>

                                        </td>
                                        <td class="<?php echo e(in_array('confirmation_number', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Confirmation Number:</strong> <?php echo e($service->confirmation_number ?? 'N/A'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="<?php echo e(in_array('gross_amount', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Gross Amount:</strong> <?php echo e($service->gross_amount ?? 'N/A'); ?>

                                        </td>
                                        <td class="<?php echo e(in_array('net', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Net Amount:</strong> <?php echo e($service->net ?? 'N/A'); ?>

                                        </td>
                                        <td class="<?php echo e(in_array('service_fees', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Service Fees:</strong> <?php echo e($service->service_fees ?? 'N/A'); ?>

                                        </td>
                                        <td class="<?php echo e(in_array('mask_fees', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Mask Fees:</strong> <?php echo e($service->mask_fees ?? 'N/A'); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <?php if($service->tcs): ?>
                                            <td class="<?php echo e(in_array('tcs', $updates) ? 'highlight' : ''); ?>">
                                                <strong>TCS:</strong> <?php echo e($service->tcs ?? 'N/A'); ?>

                                            </td>
                                        <?php endif; ?>
                                        <td class="<?php echo e(in_array('card_id', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Card:</strong> <?php echo e($service->card->card_name ?? 'N/A'); ?>

                                        </td>
                                        <td class="<?php echo e(in_array('supplier_id', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Supplier:</strong> <?php echo e($service->supplier->name ?? 'N/A'); ?>

                                        </td>
                                        <td class="<?php echo e(in_array('bill_to', $updates) || in_array('bill_to_remark', $updates) ? 'highlight' : ''); ?>">
                                            <strong>Bill To:</strong> <?php echo e(ucfirst($service->bill_to) ?? 'N/A'); ?> - <?php echo e($service->bill_to_remark ?? 'N/A'); ?>

                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-muted">No service details available.</p>
                    <?php endif; ?>
                </div>

            </div>

            <!-- Remarks -->
            
                <div class="card mb-4 shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="m-0">Remarks</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Remark Type</th>
                                    <th>Remark</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Shared</th>
                                    <th>Added by</th>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounts')): ?>
                                    <th>Acknowledge<span class="text-danger">*</span></th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <?php $__empty_1 = true; $__currentLoopData = $booking->bookingRemarks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $remark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounts')): ?>
                                        <?php if($remark->remark_type !== 'account'): ?>
                                            <?php continue; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <tr>
                                        <td><?php echo e(ucfirst($remark->remark_type)); ?></td>
                                        <td><?php echo e($remark->description ?? 'N/A'); ?></td>
                                        <td><?php echo e($remark->created_at->format('d/m/Y')); ?></td> <!-- Format Date -->
                                        <td><?php echo e($remark->created_at->format('H:i')); ?></td>
                                        <td><?php echo e($remark->is_shareable ? 'Yes' : 'No'); ?></td>
                                        <td><?php echo e($remark->addedBy->first_name ?? 'N/A'); ?> <?php echo e($remark->addedBy->last_name ?? 'N/A'); ?></td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounts')): ?>
                                            <td>
                                                <?php if(!$remark->is_acknowledged): ?> <!-- Only show checkbox if not acknowledged -->
                                                    
                                                    <input type="checkbox" name="is_ack" id="is_ack_<?php echo e($remark->id); ?>"
                                                        class="form-check-input is-ack-checkbox" style="position: relative; margin-left:2px;">
                                                <?php else: ?>
                                                    <!-- Green Tick Mark for Acknowledged Remarks -->
                                                    <span class="text-success" style="font-size: 20px;">&#10003;</span> <!-- Check mark symbol -->
                                                <?php endif; ?>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="6" class="text-muted text-center">No remarks available.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    
                </div>
            

            <!-- Approval -->
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounts')): ?>
            <div class="card mb-4 shadow-sm">
                <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                    <h5 class="m-0">Approval</h5>
                    <button class="btn btn-link text-white toggle-collapse" data-bs-toggle="collapse" data-bs-target="#approvalCollapse" aria-expanded="true" aria-controls="approvalCollapse">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>

                <div id="approvalCollapse" class="collapse">

                    <form action="<?php echo e(route('booking.approve', $booking->id)); ?>" id="approval_form" method="POST">
                        <div class="card-body">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="mb-3 col-md-6">
                                    <label for="invoice_number" class="form-label">Invoice Number</label>
                                    <input type="text" name="invoice_number" id="invoice_number" class="form-control"
                                        placeholder="Enter Invoice Number"
                                        value="<?php echo e(old('invoice_number', $booking->invoice_number)); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="card-footer d-flex justify-content-center">
                            <input type="hidden" name="approve" value="1">
                            <button type="submit" id="approve_button" class="btn btn-secondary approve"
                                data-booking-id="<?php echo e($booking->id); ?>"
                                onclick="handleAcknowledgeButton(event, <?php echo e($booking->id); ?>)">Approve</button>
                        </div>
                    </form>


                </div>
            </div>


            <!-- Add Remarks -->
            <div class="card mb-4 shadow-sm">

                <div class="card-header bg-secondary text-white d-flex justify-content-between align-items-center">
                    <h5 class="m-0">Add Remarks</h5>
                    <button class="btn btn-link text-white toggle-collapse" data-bs-toggle="collapse" data-bs-target="#addremarksCollapse" aria-expanded="true" aria-controls="addremarksCollapse">
                        <i class="fas fa-chevron-down"></i>
                    </button>
                </div>
                <div id="addremarksCollapse" class="collapse">
                
                    <form action="" id="add_remarks_form" method="POST">
                    <div class="card-body">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div id="remarksContainer" class="col-12 col-md-12">
                                    <div class="remark-group row col-12 col-md-12" id="remark_group_1">
                                        <div class="mb-3 col col-4">
                                            <label for="remark_type" class="form-label">Remark Type </label>
                                            <select name="remark_type" id="remark_type" class="form-select form-control">
                                                <option value="" disabled>Select</option>
                                                <option value="office">Office</option>
                                                <option value="account">Accounts</option>
                                            </select>
                                            <?php $__errorArgs = ['remark_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="mb-3 col col-8">
                                            <label for="remark" class="form-label">Remark </label>
                                            <textarea name="remark" id="remark" cols="" rows="" class="form-control"></textarea>
                                            <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                    </div>

                    <div class="card-footer d-flex justify-content-center">
                        <input type="hidden" name="update" value="1">
                        <button type="button" id="update_button" class="btn btn-secondary update" data-booking-id="<?php echo e($booking->id); ?>">Update</button>
                    </div>

                </form>
            </div>
            </div>

            

            <?php endif; ?>
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

</div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script>
function handleAcknowledgeButton(event, bookingId) {
    // Prevent form submission
    event.preventDefault();

    // Get all checkboxes with the 'is-ack-checkbox' class
    const checkboxes = document.querySelectorAll('.is-ack-checkbox');

    // Check if there are any checkboxes in the DOM
    if (checkboxes.length === 0) {
        // If no checkboxes, allow form submission
        document.getElementById('approval_form').submit();
        return;
    }

    // Check if all checkboxes are checked
    const areAllChecked = Array.from(checkboxes).every(checkbox => checkbox.checked);

    if (areAllChecked) {
        // If all checkboxes are checked, submit the form
        document.getElementById('approval_form').submit();
    } else {
        // If not all checkboxes are checked, show an alert and prevent submission
        alert('Please acknowledge all remarks by checking each box before proceeding.');
    }
}


        function sendAjaxRequest(bookingId) {
            fetch(`/bookings/accept/${bookingId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Optionally, refresh the page or update the UI
                } else {
                    alert('Failed to acknowledge the remarks the booking. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert(data.message);
            });
        }

        function approveBooking(bookingId) {
            fetch(`/bookings/approve/${bookingId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Optionally, refresh the page or update the UI
                } else {
                    alert('Failed to accept the booking. Please try again.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert(data.message);
            });
        }

    </script>


<script>
    document.querySelector('.toggle-collapse').addEventListener('click', function () {
        const icon = this.querySelector('i');
        const isCollapsed = this.getAttribute('aria-expanded') === 'true';

        if (isCollapsed) {
            icon.classList.remove('fa-chevron-down');
            icon.classList.add('fa-chevron-up');
        } else {
            icon.classList.remove('fa-chevron-up');
            icon.classList.add('fa-chevron-down');
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/booking/show.blade.php ENDPATH**/ ?>