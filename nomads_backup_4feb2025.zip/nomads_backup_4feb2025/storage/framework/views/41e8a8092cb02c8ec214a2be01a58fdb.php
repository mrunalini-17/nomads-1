<?php if(session()->has('error')): ?>

<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong><?php echo e(session('error')); ?></strong>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>

<?php endif; ?>
<?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/shared/error-message.blade.php ENDPATH**/ ?>