<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    
                    <div class="py-3 px-2">
                        <h3 class="font-weight-bold text-primary">Designation List</h3>
                    </div>

                    

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">

                            <div class="text-right mb-3"><button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#addModal"> Create Designation</button></div>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped" id="dataTable" cellspacing="0">
                                       <thead class="bg-light text-dark">
                                        <tr>
                                            <th>Sr No</th>
                                            <th>Designation Name</th>
                                            <th>Description</th>
                                            <th>Added by</th>
                                            <th>Updated by</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($designation->designation_name); ?></td>
                                                <td><?php echo e($designation->description ?: '--'); ?></td>
                                                <td>
                                                    <?php if($designation->addedBy): ?>
                                                        <?php echo e($designation->addedBy->first_name ?? 'N/A'); ?>

                                                        <?php echo e($designation->addedBy->last_name ?? 'N/A'); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($designation->updatedBy): ?>
                                                        <?php echo e($designation->updatedBy->first_name ?? 'N/A'); ?>

                                                        <?php echo e($designation->updatedBy->last_name ?? 'N/A'); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="text-center">
                                                        <!-- Dropdown button -->
                                                        <div class="dropdown">
                                                            <button
                                                                class="text-info border-0 bg-transparent dropdown-toggle"
                                                                type="button" id="dropdownMenuButton<?php echo e($designation->id); ?>"
                                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                                <i class="fa-solid fa-ellipsis-vertical"></i>
                                                            </button>
                                                            <ul class="dropdown-menu"
                                                                aria-labelledby="dropdownMenuButton<?php echo e($designation->id); ?>">
                                                                <li>
                                                                    <a class="dropdown-item text-success view-design-btn"
                                                                       href="javascript:void(0);"
                                                                       data-design-name="<?php echo e($designation->designation_name); ?>"
                                                                       data-description="<?php echo e($designation->description); ?>">
                                                                        <i class="fa-solid fa-eye"></i> View
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    
                                                                    <button class="dropdown-item text-primary edit-design-btn"
                                                                            data-card='<?php echo json_encode($designation, 15, 512) ?>'>
                                                                        <i class="fa-solid fa-edit"></i> Edit
                                                                    </button>
                                                                </li>
                                                                <li>
                                                                    <form
                                                                        action="<?php echo e(route('designation.destroy', $designation->id)); ?>"
                                                                        method="POST" style="display:inline;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button class="dropdown-item text-danger"
                                                                            onclick="return confirm('Are you sure you want to delete this designation?');">
                                                                            <i class="fa-solid fa-trash"></i> Delete
                                                                        </button>
                                                                    </form>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                                
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

            <!-- View Modal -->
            <div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="viewModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6 class="modal-title m-0 font-weight-bold text-primary" id="viewModalLabel">Designation Details</h6>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <table class="table table-striped">
                                <tbody>
                                    <tr>
                                        <th>Designation Name</th>
                                        <td id="modalDesignationName"></td>
                                    </tr>
                                    <tr>
                                        <th>Description</th>
                                        <td id="modalDescription"></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Edit Modal -->
            <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">>
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6 class="modal-title m-0 font-weight-bold text-primary" id="editModalLabel">Edit Designation</h6>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <form id="editForm" action="" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="mb-3 col-12">
                                        <label for="edit_designation_name" class="form-label">Designation Name</label>
                                        <input type="text" class="form-control" id="edit_designation_name" name="designation_name" required>
                                    </div>
                                    <div class="mb-3 col-12">
                                        <label for="edit_description" class="form-label">Description</label>
                                        <textarea class="form-control" id="edit_description" name="description"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-success">Update</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Create Modal -->
            <div class="modal fade" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">>
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6 class="modal-title m-0 font-weight-bold text-primary" id="addModalLabel">Create Designation</h6>
                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo e(route('designation.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="mb-3 col-12">
                                        <label for="card_name" class="form-label">Designation Name</label>
                                        <input type="text" class="form-control" id="designation_name" name="designation_name" required>
                                    </div>
                                    <div class="mb-3 col-12">
                                        <label for="description" class="form-label">Description</label>
                                        <textarea class="form-control" id="description" name="description"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-success">Submit</button>
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>


            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Get all view buttons
                    const viewButtons = document.querySelectorAll('.view-design-btn');

                    viewButtons.forEach(button => {
                        button.addEventListener('click', function() {
                            // Get the card data from data attributes
                            const designName = this.getAttribute('data-design-name');
                            const description = this.getAttribute('data-description') || '--';

                            // Populate the modal with the card data
                            document.getElementById('modalDesignationName').textContent = designName;
                            document.getElementById('modalDescription').textContent = description;

                            // Show the modal
                            const viewModal = new bootstrap.Modal(document.getElementById('viewModal'));
                            viewModal.show();
                        });
                    });


                    // Edit modal handle
                    const editModal = document.getElementById('editModal');
                    const nameInput = document.getElementById('edit_designation_name');
                    const descriptionInput = document.getElementById('edit_description');
                    const editForm = document.getElementById('editForm');

                    document.querySelectorAll('.edit-design-btn').forEach(button => {
                        button.addEventListener('click', function() {
                            const design = JSON.parse(this.getAttribute('data-card'));

                            // Fill the modal with the card data
                            nameInput.value = design.designation_name;
                            descriptionInput.value = design.description || '';

                            // Update form action to the correct route
                            editForm.action = `/designation/${design.id}/update`;

                            // Show the modal
                            new bootstrap.Modal(editModal).show();
                        });
                    });
                });
            </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/designation/index.blade.php ENDPATH**/ ?>