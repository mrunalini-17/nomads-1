<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nomads Holidays : Booking Confirmation</title>

</head>
<body>
    <div class="container" style="font-family: Arial, sans-serif; line-height: 1.6; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px;">
        <h1 style="color: #333; text-align: center;">Booking Confirmation</h1>

        <p>Dear <?php echo e($booking->customer->fname); ?> <?php echo e($booking->customer->lname); ?>,</p>

        <p>We are pleased to confirm your booking with Nomads Holidays. Here are the details of your booking:</p>

        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
            
            <tr>
                <th style="text-align: left; padding: 8px; background-color: #f8f8f8; border: 1px solid #ddd;">Customer Name</th>
                <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e($booking->customer->fname); ?> <?php echo e($booking->customer->lname); ?></td>
            </tr>
            <tr>
                <th style="text-align: left; padding: 8px; background-color: #f8f8f8; border: 1px solid #ddd;">Booking Date</th>
                <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('d M, Y')); ?></td>
            </tr>
            <tr>
                <th style="text-align: left; padding: 8px; background-color: #f8f8f8; border: 1px solid #ddd;">Bill Amount</th>
                <td style="padding: 8px; border: 1px solid #ddd;"><?php echo e(number_format($booking->bill_amount, 2)); ?> <?php echo e($booking->currency); ?></td>
            </tr>
        </table>

        <p>If you have any questions or need assistance, please do not hesitate to contact us at <a href="mailto:support@nomadsholidays.com" style="color: #007bff; text-decoration: none;">support@nomadsholidays.com</a>.</p>

        <p>Thank you for choosing Nomads Holidays for your travel needs. We look forward to serving you!</p>

        <div style="margin-top: 20px; text-align: left;">
            <p>Best Regards,</p>
            <p><strong>Team Nomads Holidays</strong></p>
        </div>

        <footer style="margin-top: 30px; text-align: center; color: #888;">
            <p style="font-size: 12px;">Nomads Holidays, All rights reserved.</p>
            <p style="font-size: 12px;">This is an automated email. Please do not reply to this message.</p>
        </footer>
    </div>
</body>

</html>
<?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/emails/booking_confirmation_mail_client.blade.php ENDPATH**/ ?>