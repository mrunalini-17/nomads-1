<!-- Sidebar -->
<ul class="navbar-nav sidebar sidebar-dark accordion bg-gradient-primary" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('index')); ?>">
        <div class="sidebar-brand-text mx-3"><small></small><img src="<?php echo e(asset('assets/img/nomadlogo.png')); ?>" width="100"> </div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link " href="<?php echo e(route('index')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Nav Item - Employee Management (Admin and Manager) -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin'])): ?>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#employeeManagement" aria-expanded="true" aria-controls="employeeManagement">
            <i class="fas fa-fw fa-user-tie"></i>
            <span>Employee Management</span>
        </a>
        <div id="employeeManagement" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('employees.index')); ?>">Employee</a>
            </div>
        </div>
    </li>
    <?php endif; ?>

    <!-- Nav Item - Customer Management (Admin, Manager, and Operations) -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin'])): ?>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#customerManagement" aria-expanded="true" aria-controls="customerManagement">
            <i class="fas fa-fw fa-users"></i>
            <span>Customer Management</span>
        </a>
        <div id="customerManagement" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('customers.index')); ?>">Customer</a>
            </div>
        </div>
    </li>
    <?php endif; ?>


        <!-- Nav Item - Enquiry Management (Admin and Manager) -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin','manager','operations'])): ?>
        <li class="nav-item">
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#enquiryManagement" aria-expanded="true" aria-controls="enquiryManagement">
                <i class="fas fa-question-circle"></i>
                <span>Enquiry Management</span>
            </a>
            <div id="enquiryManagement" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin','manager'])): ?>
                        <a class="collapse-item" href="<?php echo e(route('enquiries.index')); ?>">All Enquiries</a>
                    <?php endif; ?>

                        <a class="collapse-item" href="<?php echo e(route('new_enquiries.index')); ?>">New Enquiries</a>
                        <a class="collapse-item" href="<?php echo e(route('accepted_enquiries.index')); ?>">Accepted Enquiries</a>
                        <a class="collapse-item" href="<?php echo e(route('followups.index')); ?>">Followups</a>
                        <a class="collapse-item" href="<?php echo e(route('enquiries.create')); ?>">Create Enquiry</a>
                </div>
            </div>
        </li>
        <?php endif; ?>

    <!-- Nav Item - Booking Management (All roles) -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin','manager', 'accounts', 'operations'])): ?>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#bookingManagement" aria-expanded="true" aria-controls="bookingManagement">
            <i class="fas fa-fw fa-calendar-alt"></i>
            <span>Booking Management</span>
        </a>
        <div id="bookingManagement" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin','manager'])): ?>
                    <a class="collapse-item" href="<?php echo e(route('bookings.index')); ?>">Bookings</a>
                    
                    <a class="collapse-item" href="<?php echo e(route('bookings.create')); ?>">Create Booking</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operations')): ?>
                    <a class="collapse-item" href="<?php echo e(route('bookings.operations_index')); ?>">Bookings</a>
                    <a class="collapse-item" href="<?php echo e(route('bookings.create')); ?>">Create Booking</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('accounts')): ?>
                    <a class="collapse-item" href="<?php echo e(route('bookings.pending_index')); ?>">Pending Bookings</a>
                    <a class="collapse-item" href="<?php echo e(route('bookings.approved_index')); ?>">Approved Bookings</a>
                <?php endif; ?>


            </div>
        </div>
    </li>
    <?php endif; ?>

    <!-- Nav Item - Master (Admin only) -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin'])): ?>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsefour" aria-expanded="true" aria-controls="collapsefour">
            <i class="fas fa-fw fa-cogs"></i>
            <span>Master</span>
        </a>
        <div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('cards.index')); ?>">Cards</a>
                <a class="collapse-item" href="<?php echo e(route('departments.index')); ?>">Department</a>
                <a class="collapse-item" href="<?php echo e(route('designations.index')); ?>">Designation</a>
                <a class="collapse-item" href="<?php echo e(route('subdepartments.index')); ?>">Sub Department</a>
                <a class="collapse-item" href="<?php echo e(route('references.index')); ?>">References</a>
                <a class="collapse-item" href="<?php echo e(route('roles.index')); ?>">Role</a>
                <a class="collapse-item" href="<?php echo e(route('services.index')); ?>">Services</a>
                <a class="collapse-item" href="<?php echo e(route('suppliers.index')); ?>">Suppliers</a>
                <a class="collapse-item" href="<?php echo e(route('sources.index')); ?>">Sources</a>
            </div>
        </div>
    </li>
    <?php endif; ?>

    <!-- Nav Item - Notifications and Reminders (Admin only) -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin'])): ?>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
            <i class="fas fa-fw fa-bell"></i>
            <span>Notification & Reminder</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="<?php echo e(route('notifications.index')); ?>">Notification</a>
                <a class="collapse-item" href="<?php echo e(route('reminders.index')); ?>">Reminder</a>

            </div>
        </div>
    </li>
    <?php endif; ?>


    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseReports" aria-expanded="true" aria-controls="collapseReports">
            <i class="fas fa-fw fa-table"></i>
            <span>Reports</span>
        </a>
        <div id="collapseReports" class="collapse" aria-labelledby="headingReports" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin','manager'])): ?>
                <a class="collapse-item" href="<?php echo e(route('enquiryreports.index')); ?>">Enquiry Reports</a>
                <a class="collapse-item" href="<?php echo e(route('bookingreports.index')); ?>">Booking Reports</a>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operations')): ?>
                <a class="collapse-item" href="<?php echo e(route('operations_enquiryreports.index')); ?>">Enquiry Reports</a>
                <a class="collapse-item" href="<?php echo e(route('operations_bookingreports.index')); ?>">Booking Reports</a>
                <?php endif; ?>
            </div>
        </div>
    </li>


    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->
<?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/shared/adminsidebar.blade.php ENDPATH**/ ?>