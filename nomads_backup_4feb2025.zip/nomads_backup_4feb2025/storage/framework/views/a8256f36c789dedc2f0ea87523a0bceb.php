<?php $__env->startSection('title', 'Lead Management'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class=" py-3 px-2">
                        <h3 class=" font-weight-bold text-primary">Sources List</h3>
                    </div>
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">

                        <div class="card-body">
                            <div class="text-right mb-3">
                                <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#createSourceModal">Create source</button>
                              </div>

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped" id="dataTable" cellspacing="0">
                                    <thead class="bg-light text-dark">
                                        <tr>
                                            <th>S.No</th>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Added by</th>
                                            <th>Updated by</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($source->title); ?></td>
                                                <td><?php echo e($source->description); ?></td>
                                                <td>
                                                    <?php if($source->addedBy): ?>
                                                        <?php echo e($source->addedBy->first_name ?? 'N/A'); ?>

                                                        <?php echo e($source->addedBy->last_name ?? 'N/A'); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($source->updatedBy): ?>
                                                        <?php echo e($source->updatedBy->first_name ?? 'N/A'); ?>

                                                        <?php echo e($source->updatedBy->last_name ?? 'N/A'); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                
                                                <td>
                                                    <div class="text-center">
                                                        <!-- Dropdown button -->
                                                        <div class="dropdown">
                                                            <button class="text-info border-0 bg-transparent dropdown-toggle" type="button" id="dropdownMenuButton<?php echo e($source->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                                                <i class="fa-solid fa-ellipsis-vertical"></i>
                                                            </button>
                                                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?php echo e($source->id); ?>">
                                                                
                                                                <li>
                                                                    <a class="dropdown-item text-primary edit-source-btn" href="#" data-id="<?php echo e($source->id); ?>">
                                                                        <i class="fa-solid fa-pen-to-square"></i> Edit
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    <form action="<?php echo e(route('sources.destroy', $source->id)); ?>" method="POST" style="display:inline;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button class="dropdown-item text-danger" onclick="return confirm('Are you sure you want to delete this source?');">
                                                                            <i class="fa-solid fa-trash"></i> Delete
                                                                        </button>
                                                                    </form>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Modal Structure -->
            <div class="modal fade" id="createSourceModal" tabindex="-1" role="dialog" aria-labelledby="createSourceModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="createSourceModalLabel">Create Source</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>
                    <div class="modal-body">
                    <!-- Form content here -->
                    <form action="<?php echo e(route('sources.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="sourceName" class="col-md-4 col-form-label">Source Name <span class="text-danger">*</span></label>

                            <div class="col-md-8">
                                <input type="text" class="form-control" id="title" name="title" placeholder="Enter source name" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="description" class="col-md-4 col-form-label">Description</label>
                            <div class="col-md-8">
                                <textarea name="description" id="description" rows="5" class="form-control"></textarea>
                            </div>
                        </div>

                        <!-- Button Group -->
                        <div class="form-group row">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-success">Submit</button>
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </form>
                    </div>

                </div>
                </div>
            </div>

            <!-- Edit Source Modal -->
            <div class="modal fade" id="editSourceModal" tabindex="-1" role="dialog" aria-labelledby="editSourceModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="editSourceModalLabel">Edit Source</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        </div>
                        <div class="modal-body">
                        <form id="editSourceForm" action="<?php echo e(route('sources.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="sourceId" name="id">
                            <div class="form-group row">
                                <label for="editTitle" class="col-md-4 col-form-label">Source Name <span class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" id="editTitle" name="title" placeholder="Enter source name" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="editDescription" class="col-md-4 col-form-label">Description</label>
                                <div class="col-md-8">
                                    <textarea class="form-control" id="editDescription" name="description" rows="5"></textarea>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn btn-success">Update</button>
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

<script>
    $(document).ready(function() {
        $('.edit-source-btn').on('click', function(e) {
            e.preventDefault();
            var sourceId = $(this).data('id');
            $.ajax({
                url: '/sources/edit/' + sourceId,
                method: 'GET',
                // data: {
                //     _token: '<?php echo e(csrf_token()); ?>'
                // },
                success: function(response) {
                    $('#editTitle').val(response.title);
                    $('#editDescription').val(response.description);
                    $('#sourceId').val(response.id);

                    $('#editSourceModal').modal('show');
                },
                error: function(xhr) {
                    console.error('Error fetching data:', xhr);
                }
            });
        });



    $('#editSourceModal .close').on('click', function() {
        $('#editSourceModal').modal('hide');
    });


    $('#editSourceModal .btn-secondary').on('click', function() {
        $('#editSourceModal').modal('hide');
    });

    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/masterdata/sources.blade.php ENDPATH**/ ?>