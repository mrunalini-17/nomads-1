<?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($booking->unique_code); ?></td>
        <td><?php echo e($booking->customer->fname ?? 'N/A'); ?> <?php echo e($booking->customer->lname ?? 'N/A'); ?></td>
        <td><?php echo e($booking->service->name ?? 'N/A'); ?></td>
        <td><?php echo e($booking->status ?? 'N/A'); ?></td>
        <td class="<?php echo e($booking->is_approved ? 'text-success' : ''); ?>"><?php echo e($booking->is_approved ? 'Yes' : 'No'); ?></td>
        <td><?php echo e(\Carbon\Carbon::parse($booking->booking_date)->format('d-m-Y')); ?></td>
        <td><?php echo e($booking->addedBy->first_name ?? '--'); ?> <?php echo e($booking->addedBy->last_name ?? '--'); ?></td>
        <td><?php echo e($booking->updatedBy->first_name ?? '--'); ?> <?php echo e($booking->updatedBy->last_name ?? '--'); ?></td>
        <td><?php echo e($booking->acceptedBy->first_name ?? '--'); ?> <?php echo e($booking->acceptedBy->last_name ?? '--'); ?></td>
        <td>
            <!-- Actions dropdown -->
            <div class="dropdown">
                <button class="text-info border-0 bg-transparent dropdown-toggle" type="button"
                    id="dropdownMenuButton<?php echo e($booking->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa-solid fa-ellipsis-vertical"></i>
                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton<?php echo e($booking->id); ?>">
                    <li><a class="dropdown-item text-success" href="<?php echo e(route('bookings.show', $booking->id)); ?>">
                        <i class="fa-solid fa-eye"></i> View
                    </a></li>

                        <li><a class="dropdown-item text-primary" href="<?php echo e(route('bookings.edit', $booking->id)); ?>">
                            <i class="fa-solid fa-pen-to-square"></i> Edit
                        </a></li>
                        <?php if($booking->is_approved != 1): ?>
                        <li>
                            <form action="<?php echo e(route('bookings.destroy', $booking->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="dropdown-item text-danger" onclick="return confirm('Are you sure?');">
                                    <i class="fa-solid fa-trash"></i> Delete
                                </button>
                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="10" class="text-center">No bookings available</td>
    </tr>
<?php endif; ?>
<?php /**PATH C:\xampp8.2.4new\htdocs\nomads\resources\views/homecontent/booking/partials/booking_table.blade.php ENDPATH**/ ?>