<?php $__env->startSection('title', 'Employee Profile'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">
        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content">
                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    <div class="text-right p-2">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm btn-primary"> Back</a>
                    </div>
                    <div class="row">
                        <!-- Profile Card -->
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title">Profile</h5>
                                </div>
                                <div class="card-body text-center">
                                    <img src="<?php echo e($employee->profile_image ? asset($employee->profile_image) : asset('assets/img/undraw_profile.svg')); ?>"
                                        alt="Profile Image" class="img-profile rounded-circle"
                                        style="width: 150px; height: 150px;">
                                    <h4 class="mt-3"><?php echo e($employee->first_name); ?> <?php echo e($employee->last_name); ?></h4>
                                    <p class="text-muted"><?php echo e($employee->userRole ? $employee->userRole->name : 'No Role Assigned'); ?></p>
                                </div>
                            </div>
                        </div>

                        <!-- Profile Details -->
                        <div class="col-md-8">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <h5 class="card-title">Personal Details</h5>
                                </div>
                                <div class="card-body">
                                    <dl class="row">
                                        <dt class="col-sm-3">Email:</dt>
                                        <dd class="col-sm-9"><?php echo e($employee->email); ?></dd>

                                        <dt class="col-sm-3">Mobile:</dt>
                                        <dd class="col-sm-9"><?php echo e($employee->mobile); ?></dd>

                                        <dt class="col-sm-3">WhatsApp:</dt>
                                        <dd class="col-sm-9"><?php echo e($employee->whatsapp); ?></dd>

                                        <dt class="col-sm-3">Departments:</dt>
                                        <dd class="col-sm-9">
                                            <?php if($employee->departments->isNotEmpty()): ?>
                                                <ul>
                                                    <?php $__currentLoopData = $employee->departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <li><?php echo e($department->department_name); ?></li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            <?php else: ?>
                                                No Departments Assigned
                                            <?php endif; ?>
                                        </dd>

                                        <dt class="col-sm-3">Designation:</dt>
                                        <dd class="col-sm-9">
                                            <?php echo e($employee->designation ? $employee->designation->designation_name : 'Not Assigned'); ?>

                                        </dd>

                                        <dt class="col-sm-3">Miscellaneous:</dt>
                                        <dd class="col-sm-9"><?php echo e($employee->miscellaneous); ?></dd>
                                    </dl>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <!-- Change Password -->
                        <a href="#">Change Password</a>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->
        </div>
        <!-- End of Content Wrapper -->
    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/employee/profile.blade.php ENDPATH**/ ?>