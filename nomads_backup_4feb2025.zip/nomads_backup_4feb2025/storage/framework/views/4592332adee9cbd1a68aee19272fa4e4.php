<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    
                    <div class=" py-3 px-2">
                        <h3 class=" font-weight-bold text-primary">Department List</h3>
                    </div>

                    <div class="text-right p-2">
                        
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            
                            <div class="text-right mb-3"><button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#addDepartmentModal"> Create Department</button></div>


                            <div class="table-responsive">

                                <table class="table table-bordered table-striped" id="dataTable" cellspacing="0">
                                       <thead class="bg-light text-dark">
                                        <tr>
                                            <th>Sr no</th>
                                            <th>Department</th>
                                            <th>Description</th>
                                            <th>Added by</th>
                                            <th>Updated by</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($department->department_name); ?></td>
                                                <td><?php echo e($department->description ?: '--'); ?></td>
                                                <td>
                                                    <?php if($department->addedBy): ?>
                                                        <?php echo e($department->addedBy->first_name ?? 'N/A'); ?>

                                                        <?php echo e($department->addedBy->last_name ?? 'N/A'); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($department->updatedBy): ?>
                                                        <?php echo e($department->updatedBy->first_name ?? 'N/A'); ?>

                                                        <?php echo e($department->updatedBy->last_name ?? 'N/A'); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="text-center">
                                                        <!-- Dropdown button -->
                                                        <div class="dropdown">
                                                            <button
                                                                class="text-info border-0 bg-transparent dropdown-toggle"
                                                                type="button" id="dropdownMenuButton<?php echo e($department->id); ?>"
                                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                                <i class="fa-solid fa-ellipsis-vertical"></i>
                                                            </button>
                                                            <ul class="dropdown-menu"
                                                                aria-labelledby="dropdownMenuButton<?php echo e($department->id); ?>">
                                                                <li>
                                                                    <a class="dropdown-item text-success view-dept-btn"
                                                                       href="javascript:void(0);"
                                                                       data-dept-name="<?php echo e($department->department_name); ?>"
                                                                       data-description="<?php echo e($department->description); ?>">
                                                                        <i class="fa-solid fa-eye"></i> View
                                                                    </a>
                                                                </li>
                                                                <li>
                                                                    
                                                                    <button class="dropdown-item text-primary edit-dept-btn"
                                                                            data-card='<?php echo json_encode($department, 15, 512) ?>'>
                                                                        <i class="fa-solid fa-edit"></i> Edit
                                                                    </button>
                                                                </li>
                                                                <li>
                                                                    <form
                                                                        action="<?php echo e(route('department.destroy', $department->id)); ?>"
                                                                        method="POST" style="display:inline;">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button class="dropdown-item text-danger"
                                                                            onclick="return confirm('Are you sure you want to delete this Department?');">
                                                                            <i class="fa-solid fa-trash"></i> Delete
                                                                        </button>
                                                                    </form>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                                

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

        <!-- View Department Modal -->
        <div class="modal fade" id="viewDepartmentModal" tabindex="-1" aria-labelledby="viewDepartmentModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        
                        <h6 class="modal-title m-0 font-weight-bold text-primary" id="viewDepartmentModalLabel">Department Details</h6>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <table class="table table-striped">
                            <tbody>
                                <tr>
                                    <th>Department Name</th>
                                    <td id="modalDepartmentName"></td>
                                </tr>
                                <tr>
                                    <th>Description</th>
                                    <td id="modalDescription"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Edit Department Modal -->
        <div class="modal fade" id="editDepartmentModal" tabindex="-1" aria-labelledby="editDepartmentModalLabel" aria-hidden="true">>
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title m-0 font-weight-bold text-primary" id="editDepartmentModalLabel">Edit Department</h6>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form id="editDepartmentForm" action="" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="mb-3 col-12">
                                    <label for="edit_department_name" class="form-label">Department Name</label>
                                    <input type="text" class="form-control" id="edit_department_name" name="department_name" required>
                                </div>
                                <div class="mb-3 col-12">
                                    <label for="edit_description" class="form-label">Description</label>
                                    <textarea class="form-control" id="edit_description" name="description"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-success">Update</button>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Create Department Modal -->
        <div class="modal fade" id="addDepartmentModal" tabindex="-1" aria-labelledby="addDepartmentModalLabel" aria-hidden="true">>
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6 class="modal-title m-0 font-weight-bold text-primary" id="addDepartmentModalLabel">Add Department</h6>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('department.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="mb-3 col-12">
                                    <label for="card_name" class="form-label">Department Name</label>
                                    <input type="text" class="form-control" id="department_name" name="department_name" required>
                                </div>
                                <div class="mb-3 col-12">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control" id="description" name="description"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <div class="text-center">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Get all view buttons
                const viewButtons = document.querySelectorAll('.view-dept-btn');

                viewButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        // Get the card data from data attributes
                        const deptName = this.getAttribute('data-dept-name');
                        const description = this.getAttribute('data-description') || '--';

                        // Populate the modal with the card data
                        document.getElementById('modalDepartmentName').textContent = deptName;
                        document.getElementById('modalDescription').textContent = description;

                        // Show the modal
                        const viewDepartmentModal = new bootstrap.Modal(document.getElementById('viewDepartmentModal'));
                        viewDepartmentModal.show();
                    });
                });


                // Edit modal handle
                const editModal = document.getElementById('editDepartmentModal');
                const nameInput = document.getElementById('edit_department_name');
                const descriptionInput = document.getElementById('edit_description');
                const editForm = document.getElementById('editDepartmentForm');

                document.querySelectorAll('.edit-dept-btn').forEach(button => {
                    button.addEventListener('click', function() {
                        const dept = JSON.parse(this.getAttribute('data-card'));

                        // Fill the modal with the card data
                        nameInput.value = dept.department_name;
                        descriptionInput.value = dept.description || '';

                        // Update form action to the correct route
                        editForm.action = `/department/${dept.id}/update`;

                        // Show the modal
                        new bootstrap.Modal(editDepartmentModal).show();
                    });
                });
            });
        </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/department/index.blade.php ENDPATH**/ ?>