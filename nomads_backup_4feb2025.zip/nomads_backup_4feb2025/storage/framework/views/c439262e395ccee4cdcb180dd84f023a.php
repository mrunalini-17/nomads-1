<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php echo $__env->make('shared.adminsidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php echo $__env->make('shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    
                    <div class="py-3 px-2">
                        <h3 class="font-weight-bold text-primary">Accepted Enquiry List</h3>
                    </div>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped" id="dataTable" cellspacing="0">
                                       <thead class="bg-light text-dark">
                                        <tr>
                                            <th>ID</th>
                                            <th>Name & Mobile</th>
                                            <th>Service</th>
                                            <th>Notes</th>
                                            <th>Priority</th>
                                            <th>Status</th>
                                            <th>Added by</th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('operations')): ?><th>Accepted by</th><?php endif; ?>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $enquiries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enquiry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="<?php echo e($enquiry->is_transferred ? 'table-warning' : ''); ?>">
                                                <td><?php echo e($enquiry->unique_code); ?></td>
                                                <td><?php echo e($enquiry->fname); ?> <?php echo e($enquiry->lname); ?><br><?php echo e($enquiry->mobile); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $enquiry->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($service->name); ?><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td><?php echo e($enquiry->note); ?></td>
                                                <td><?php echo e($enquiry->priority); ?></td>
                                                <td class="text-success"><?php echo e($enquiry->status); ?></td>
                                                <td>
                                                    <?php if($enquiry->addedBy): ?>
                                                        <?php echo e($enquiry->addedBy->first_name ?? 'N/A'); ?> <?php echo e($enquiry->addedBy->last_name ?? 'N/A'); ?>

                                                        <br>
                                                        <small><?php echo e($enquiry->created_at ? $enquiry->created_at->format('d-m-Y') : 'N/A'); ?></small>
                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('operations')): ?>
                                                <td class="<?php echo e($enquiry->accepted_by ? 'text-success' : 'text-center'); ?>">
                                                    <?php if($enquiry->is_accepted == 0): ?>
                                                        --
                                                    <?php elseif($enquiry->is_accepted == 1 && $enquiry->acceptedBy): ?>
                                                        <?php echo e(optional($enquiry->acceptedBy)->first_name . ' ' . optional($enquiry->acceptedBy)->last_name); ?>

                                                        <br>
                                                        <small><?php echo e($enquiry->accepted_at ? $enquiry->accepted_at->format('d-m-Y') : 'N/A'); ?></small>
                                                    <?php else: ?>
                                                        --
                                                    <?php endif; ?>
                                                </td>
                                                <?php endif; ?>
                                                <td>
                                                    <div class="text-left">

                                                        <a class="button text-success mx-1" href="<?php echo e(route('update_accepted', $enquiry->id)); ?>">
                                                            <i class="fa-solid fa-pen-to-square"></i> Edit
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- /.container-fluid -->
            </div>
            <!-- End of Main Content -->

            <?php echo $__env->make('shared.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

                

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable({
                order: [[0, 'desc']],
                responsive: true,
                columnDefs: [
                    { orderable: false, targets: -1 }
                ]
            });
        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp8.2.4\htdocs\nomads\resources\views/homecontent/enquirie/accepted_index.blade.php ENDPATH**/ ?>