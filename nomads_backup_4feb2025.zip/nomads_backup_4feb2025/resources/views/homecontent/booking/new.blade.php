@extends('layout.app')
@section('title', 'Dashboard')

@section('content')
    <!-- Page Wrapper -->
    <div id="wrapper">

        @include('shared.adminsidebar')

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                @include('shared.navbar')
                <!-- End of Topbar -->
                <div class="container mt-5">
                    <div class="card">
                        <div class="card-body bg-white">
                            <form action="{{ route('bookings.update', $booking->id) }}" method="POST">
                                @csrf
                                @method('PUT')

                                <!-- Tab Navigation -->
                                <ul class="nav nav-tabs" id="tabMenu" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="section1-tab" data-toggle="tab" href="#section1"
                                            role="tab" aria-controls="section1" aria-selected="true">Customer
                                            Details</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="section2-tab" data-toggle="tab" href="#section2"
                                            role="tab" aria-controls="section2" aria-selected="false">Booking
                                            Details</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="section3-tab" data-toggle="tab" href="#section3"
                                            role="tab" aria-controls="section3" aria-selected="false">Service
                                            Details</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="section4-tab" data-toggle="tab" href="#section4"
                                            role="tab" aria-controls="section4" aria-selected="false">Transaction
                                            Details</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="section5-tab" data-toggle="tab" href="#section5"
                                            role="tab" aria-controls="section5" aria-selected="false">Remark Details</a>
                                    </li>
                                </ul>

                                <!-- Tab Content -->
                                <div class="tab-content" id="tabContent">
                                    <!-- Section 1: Customer Details -->
                                    <div class="tab-pane fade show active" id="section1" role="tabpanel"
                                        aria-labelledby="section1-tab">
                                        <!-- Content for Customer Details -->
                                        <div class="row">
                                            <div class="mb-3 col col-4">
                                                <label for="customer_name" class="form-label">Customer</label>
                                                <input type="text" id="customer_name" class="form-control"
                                                    value="{{ $booking->customer ? $booking->customer->fname . ' ' . $booking->customer->lname : 'N/A' }}"
                                                    readonly>
                                                <!-- Hidden Input to store customer_id -->
                                                <input type="hidden" id="customer_id" name="customer_id"
                                                    value="{{ $booking->customer_id }}">
                                            </div>
                                            <!-- Customer Manager Dropdown -->
                                            <div class="mb-3 col col-4">
                                                <label for="customer_manager_id" class="form-label">
                                                    Customer Manager <span class="text-danger">*</span>
                                                </label>
                                                <div class="d-flex">
                                                    <select id="customer_manager_id" name="customer_manager_id"
                                                        class="form-select form-control" required>
                                                        <option value="" disabled>Select a manager</option>
                                                        @foreach ($customerManagers as $manager)
                                                            <option value="{{ $manager->id }}"
                                                                {{ old('customer_manager_id', $booking->customer_manager_id) == $manager->id ? 'selected' : '' }}>
                                                                {{ $manager->fname }} {{ $manager->lname }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                    <button type="button" class="btn btn-primary" id="have_manager"
                                                        data-bs-toggle="modal" data-bs-target="#managerModal">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>

                                            </div>
                                            <!-- Adult and Child Count -->
                                            <div class="mb-3 col col-4">
                                                <label for="passenger_count_number" class="form-label">
                                                    Co-passengers Count <span class="text-danger">*</span>
                                                </label>
                                                <input type="number" name="passenger_count" id="passenger_count_number"
                                                    class="form-control"
                                                    value="{{ old('passenger_count', $booking->passengerCounts->count()) }}"
                                                    required readonly>
                                            </div>
                                            <div class="col-12">
                                                <!-- Include booking_id as a hidden input -->
                                                <input type="hidden" name="booking_id" value="{{ $booking->id }}">
                                                <h4 class="mt-3">Passenger Details</h4>
                                                <button type="button" class="btn btn-primary" id="addPassengerBtn">Add
                                                    Passenger</button>
                                                <table class="table mt-3" id="passengerTable">
                                                    <thead>
                                                        <tr>
                                                            <th>Name</th>
                                                            <th>Age</th>
                                                            <th>Gender</th>
                                                            <th>Actions</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach ($booking->passengerCounts as $passenger)
                                                            <tr data-id="{{ $passenger->id }}">
                                                                <td>{{ $passenger->name }}</td>
                                                                <td>{{ $passenger->age }}</td>
                                                                <td>{{ ucfirst($passenger->gender) }}</td>
                                                                <td>
                                                                    <button type="button"
                                                                        class="btn btn-warning btn-sm editPassengerBtn">Edit</button>
                                                                    <button type="button"
                                                                        class="btn btn-danger btn-sm deletePassengerBtn">Delete</button>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <button type="button" class="btn btn-secondary" onclick="previousTab(1)"
                                                hidden>Previous</button>
                                            <button type="button" class="btn btn-primary" onclick="nextTab(1)">Save &
                                                Next</button>
                                        </div>
                                    </div>

                                    <!-- Section 2: Booking Details -->
                                    <div class="tab-pane fade" id="section2" role="tabpanel"
                                        aria-labelledby="section2-tab">
                                        <!-- Content for Booking Details -->
                                        <div class="row">
                                            <!-- Booking Date -->
                                            <div class="col-md-4 mb-3">
                                                <label for="booking_date" class="form-label">Booking Date <span
                                                        class="text-danger">*</span></label>
                                                <input type="date" name="booking_date" id="booking_date"
                                                    class="form-control"
                                                    value="{{ old('booking_date', $booking->booking_date) }}">
                                            </div>

                                            <!-- Booking Status -->
                                            <div class="mb-3 col col-4">
                                                <label for="status" class="form-label">Booking Status <span
                                                        class="text-danger">*</span></label>
                                                <select name="status" id="status" class="form-control">
                                                    <option value="hold"
                                                        {{ old('status', $booking->status) == 'hold' ? 'selected' : '' }}>
                                                        Hold</option>
                                                    <option value="confirmed"
                                                        {{ old('status', $booking->status) == 'confirmed' ? 'selected' : '' }}>
                                                        Confirmed</option>
                                                    <option value="rebooked"
                                                        {{ old('status', $booking->status) == 'rebooked' ? 'selected' : '' }}>
                                                        Rebooked</option>
                                                    <option value="canceled"
                                                        {{ old('status', $booking->status) == 'canceled' ? 'selected' : '' }}>
                                                        Canceled</option>
                                                </select>
                                            </div>

                                            <!-- Service -->
                                            <div class="mb-3 col col-4">
                                                <label for="service_id" class="form-label">Service <span
                                                        class="text-danger">*</span></label>
                                                <select name="service_id" id="service_id" class="form-control">
                                                    <option value="">Select service</option>
                                                    @foreach ($services as $service)
                                                        <option value="{{ $service->id }}"
                                                            {{ old('service_id', $booking->service_id) == $service->id ? 'selected' : '' }}>
                                                            {{ $service->name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <button type="button" class="btn btn-secondary"
                                                onclick="previousTab(2)">Previous</button>
                                            <button type="button" class="btn btn-primary" onclick="nextTab(2)">Save &
                                                Next</button>
                                        </div>
                                    </div>

                                    <!-- Section 3: Service Details -->
                                    <div class="tab-pane fade" id="section3" role="tabpanel"
                                        aria-labelledby="section3-tab">
                                        <!-- Content for Service Details -->
                                        <div class="row">
                                            <div id="service-details-container">
                                                <!-- Initial Service Details Group -->
                                                @foreach ($booking->bookingServices as $index => $serviceDetail)
                                                    <div class="row service-details-group mb-3">
                                                        <!-- Service Details -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="service_details_{{ $index + 1 }}">Service
                                                                    Details: <span class="text-danger">*</span></label>
                                                                <input type="text" class="form-control"
                                                                    id="service_details_{{ $index + 1 }}"
                                                                    name="service_details[]"
                                                                    placeholder="Enter service details"
                                                                    value="{{ old('service_details.' . $index, $serviceDetail->service_details) }}">
                                                            </div>
                                                        </div>
                                                        <!-- Travel Date 1 -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="travel_date1_{{ $index + 1 }}">Travel Date
                                                                    1:
                                                                    <span class="text-danger">*</span></label>
                                                                <input type="date" class="form-control"
                                                                    id="travel_date1_{{ $index + 1 }}"
                                                                    name="travel_date1[]"
                                                                    value="{{ old('travel_date1.' . $index, $serviceDetail->travel_date1) }}">
                                                            </div>
                                                        </div>
                                                        <!-- Travel Date 2 -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="travel_date2_{{ $index + 1 }}">Travel Date
                                                                    2:</label>
                                                                <input type="date" class="form-control"
                                                                    id="travel_date2_{{ $index + 1 }}"
                                                                    name="travel_date2[]"
                                                                    value="{{ old('travel_date2.' . $index, $serviceDetail->travel_date2) }}">
                                                            </div>
                                                        </div>
                                                        <!-- Confirmation Number -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label
                                                                    for="confirmation_number_{{ $index + 1 }}">Confirmation
                                                                    Number: <span class="text-danger">*</span></label>
                                                                <input type="text" class="form-control"
                                                                    id="confirmation_number_{{ $index + 1 }}"
                                                                    name="confirmation_number[]"
                                                                    placeholder="Enter confirmation number"
                                                                    value="{{ old('confirmation_number.' . $index, $serviceDetail->confirmation_number) }}">
                                                            </div>
                                                        </div>
                                                        <!-- Gross Amount -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="gross_amount_{{ $index + 1 }}">Gross
                                                                    Amount:
                                                                    <span class="text-danger">*</span></label>
                                                                <input type="number" class="form-control"
                                                                    id="gross_amount_{{ $index + 1 }}"
                                                                    name="gross_amount[]" step="0.01"
                                                                    value="{{ old('gross_amount.' . $index, $serviceDetail->gross_amount) }}">
                                                            </div>
                                                        </div>
                                                        <!-- Net Amount -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="net_{{ $index + 1 }}">Net Amount: <span
                                                                        class="text-danger">*</span></label>
                                                                <input type="number" class="form-control"
                                                                    id="net_{{ $index + 1 }}" name="net[]"
                                                                    step="0.01" placeholder="Enter net amount"
                                                                    value="{{ old('net.' . $index, $serviceDetail->net) }}">
                                                                <small id="net_amount_warning"
                                                                    class="form-text text-danger"></small>
                                                            </div>
                                                        </div>
                                                        <!-- Service Fees -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="service_fees_{{ $index + 1 }}">Service
                                                                    Fees:
                                                                    <span class="text-danger">*</span></label>
                                                                <input type="number" class="form-control"
                                                                    id="service_fees_{{ $index + 1 }}"
                                                                    name="service_fees[]" step="0.01"
                                                                    placeholder="Enter service fees"
                                                                    value="{{ old('service_fees.' . $index, $serviceDetail->service_fees) }}"
                                                                    readonly>
                                                            </div>
                                                        </div>
                                                        <!-- Mask Fees -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="mask_fees_{{ $index + 1 }}">Mask Fees:
                                                                    <span class="text-danger">*</span></label>
                                                                <input type="number" class="form-control"
                                                                    id="mask_fees_{{ $index + 1 }}" name="mask_fees[]"
                                                                    step="0.01" placeholder="Enter mask fees"
                                                                    value="{{ old('mask_fees.' . $index, $serviceDetail->mask_fees) }}">
                                                            </div>
                                                        </div>
                                                        <!-- Bill Amount -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="bill_{{ $index + 1 }}">Bill Amount: <span
                                                                        class="text-danger">*</span></label>
                                                                <input type="number" class="form-control"
                                                                    id="bill_{{ $index + 1 }}" name="bill[]"
                                                                    step="0.01" placeholder="Enter bill amount"
                                                                    value="{{ old('bill.' . $index, $serviceDetail->bill) }}"
                                                                    readonly>
                                                            </div>
                                                        </div>
                                                        <!-- TCS -->
                                                        <div class="mb-3 col-md-3" id="tcs_container"
                                                            style="display: none;">
                                                            <div class="form-group">
                                                                <label for="tcs_{{ $index + 1 }}">TCS: <span
                                                                        class="text-danger">*</span></label>
                                                                <input type="number" class="form-control"
                                                                    id="tcs_{{ $index + 1 }}" name="tcs[]"
                                                                    step="0.01" placeholder="Enter TCS amount"
                                                                    value="{{ old('tcs.' . $index, $serviceDetail->tcs) }}">
                                                            </div>
                                                        </div>
                                                        <!-- Credit Card Used -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="card_id_{{ $index + 1 }}">Credit Card Used:
                                                                    <span class="text-danger">*</span></label>
                                                                <select id="card_id_{{ $index + 1 }}" name="card_id[]"
                                                                    class="form-select form-control">
                                                                    <option value="">Select Card</option>
                                                                    @foreach ($cards as $card)
                                                                        <option value="{{ $card->id }}"
                                                                            {{ $card->id == $serviceDetail->card_id ? 'selected' : '' }}>
                                                                            {{ $card->card_name }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <!-- Supplier -->
                                                        <div class="mb-3 col-md-3">
                                                            <div class="form-group">
                                                                <label for="supplier_id_{{ $index + 1 }}">Supplier:
                                                                    <span class="text-danger">*</span></label>
                                                                <select id="supplier_id_{{ $index + 1 }}"
                                                                    name="supplier_id[]" class="form-select form-control">
                                                                    <option value="">Select Supplier</option>
                                                                    @foreach ($suppliers as $supplier)
                                                                        <option value="{{ $supplier->id }}"
                                                                            {{ $supplier->id == $serviceDetail->supplier_id ? 'selected' : '' }}>
                                                                            {{ $supplier->name }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                                <!-- Service Details Section -->
                                                <div class="col-12">
                                                    <h4 class="mt-3">Service Details</h4>
                                                    <button type="button" class="btn btn-primary" id="addServiceBtn">Add
                                                        Service</button>
                                                    <table class="table mt-3" id="serviceTable">
                                                        <thead>
                                                            <tr>
                                                                <th>Service Details</th>
                                                                <th>Travel Date 1</th>
                                                                <th>Travel Date 2</th>
                                                                <th>Confirmation Number</th>
                                                                <th>Net Amount</th>
                                                                <th>Service Fees</th>
                                                                <th>Mask Fees</th>
                                                                <th>Bill Amount</th>
                                                                <th>TCS</th>
                                                                <th>Card</th>
                                                                <th>Supplier</th>
                                                                <th>Actions</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            @foreach ($serviceDetails as $service)
                                                                <tr data-id="{{ $service->id }}">
                                                                    <td>{{ $service->service_details }}</td>
                                                                    <td>{{ $service->travel_date1 }}</td>
                                                                    <td>{{ $service->travel_date2 }}</td>
                                                                    <td>{{ $service->confirmation_number }}</td>
                                                                    <td>{{ $service->net }}</td>
                                                                    <td>{{ $service->service_fees }}</td>
                                                                    <td>{{ $service->mask_fees }}</td>
                                                                    <td>{{ $service->bill }}</td>
                                                                    <td>{{ $service->tcs }}</td>
                                                                    <td>{{ $service->card ? $service->card->card_name : 'N/A' }}
                                                                    </td>
                                                                    <td>{{ $service->supplier ? $service->supplier->name : 'N/A' }}
                                                                    </td>
                                                                    <td>
                                                                        <button type="button" class="btn btn-warning btn-sm editServiceBtn" data-id="{{ $service->id }}">Edit</button>
                                                                        <button type="button"
                                                                            class="btn btn-danger btn-sm deleteServiceBtn">Delete</button>
                                                                    </td>
                                                                </tr>
                                                            @endforeach
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <button type="button" class="btn btn-secondary"
                                                onclick="previousTab(3)">Previous</button>
                                            <button type="button" class="btn btn-primary" onclick="nextTab(3)">Save &
                                                Next</button>
                                        </div>
                                    </div>

                                    <!-- Section 4: Transaction Details -->
                                    <div class="tab-pane fade" id="section4" role="tabpanel"
                                        aria-labelledby="section4-tab">
                                        <!-- Content for Transaction Details -->
                                        <div class="row">
                                            <!-- Bill To Dropdown -->
                                            <div class="mb-3 col-3">
                                                <label for="bill_to" class="form-label">Bill To <span
                                                        class="text-danger">*</span></label>
                                                <select name="bill_to" id="bill_to" class="form-select form-control"
                                                    onchange="handleBillToChange()">
                                                    <option value="" disabled>Select Billing Option</option>
                                                    <option value="self"
                                                        {{ $booking->bill_to === 'self' ? 'selected' : '' }}>
                                                        Self</option>
                                                    <option value="company"
                                                        {{ $booking->bill_to === 'company' ? 'selected' : '' }}>Company
                                                    </option>
                                                    <option value="other"
                                                        {{ $booking->bill_to === 'other' ? 'selected' : '' }}>
                                                        Other</option>
                                                </select>
                                            </div>

                                            <!-- Self or Other Remark Field -->
                                            <div class="mb-3 col-3" id="bill_to_remark"
                                                class="form-group mb-3 {{ $booking->bill_to ? '' : 'd-none' }}">
                                                <label for="bill_to_remark_input">Remark <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="bill_to_remark" id="bill_to_remark_input"
                                                    class="form-control"
                                                    value="{{ old('bill_to_remark', $booking->bill_to_remark) }}">
                                            </div>

                                            <!-- Payment Type -->
                                            <div class="mb-3 col-3">
                                                <label for="payment_status" class="form-label">Payment Type <span
                                                        class="text-danger">*</span></label>
                                                <select name="payment_status" id="payment_status"
                                                    class="form-select form-control" onchange="toggleFields()">
                                                    <option value="instant"
                                                        {{ $booking->payment_status === 'instant' ? 'selected' : '' }}>
                                                        Instant
                                                    </option>
                                                    <option value="card"
                                                        {{ $booking->payment_status === 'card' ? 'selected' : '' }}>Card
                                                    </option>
                                                </select>
                                            </div>

                                            <!-- Payment Received Field -->
                                            <div id="payment-received-container"
                                                class="form-group mb-3 {{ $booking->payment_received_remark ? '' : 'd-none' }}">
                                                <label for="payment_received_remark">Payment Received <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="payment_received_remark"
                                                    id="payment_received_remark" class="form-control"
                                                    value="{{ old('payment_received_remark', $booking->payment_received_remark) }}">
                                            </div>

                                            <!-- Reminder Date and Time -->
                                            <div class="mb-3 col-3">
                                                <label for="office_reminder" class="form-label">Reminder Date and Time
                                                    <span class="text-danger">*</span></label>
                                                <input type="datetime-local" name="office_reminder" id="office_reminder"
                                                    class="form-control"
                                                    value="{{ old('office_reminder', $booking->office_reminder) }}">
                                            </div>

                                            <!-- PAN Number -->
                                            <div class="mb-3 col-3">
                                                <label for="pan_number" class="form-label">PAN Number <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="pan_number" id="pan_number"
                                                    class="form-control" placeholder="Enter PAN Number"
                                                    value="{{ old('pan_number', $booking->pan_number) }}">
                                            </div>

                                            <!-- Invoice Number -->
                                            <div class="mb-3 col-3">
                                                <label for="invoice_number" class="form-label">Invoice Number <span
                                                        class="text-danger">*</span></label>
                                                <input type="text" name="invoice_number" id="invoice_number"
                                                    class="form-control" placeholder="Enter Invoice Number"
                                                    value="{{ old('invoice_number', $booking->invoice_number) }}">
                                            </div>

                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <button type="button" class="btn btn-secondary"
                                                onclick="previousTab(4)">Previous</button>
                                            <button type="button" class="btn btn-primary" onclick="nextTab(4)">Save &
                                                Next</button>
                                        </div>
                                    </div>

                                    <!-- Section 5: Remark Details -->
                                    <div class="tab-pane fade" id="section5" role="tabpanel"
                                        aria-labelledby="section5-tab">
                                        <!-- Content for Remark Details -->
                                        <div class="row">
                                            <div class="form-group mb-3 col-md-4">
                                                <label for="client_remark">Client Remark <span
                                                        class="text-danger">*</span></label>
                                                <textarea name="client_remark" id="client_remark" class="form-control" rows="2"
                                                    placeholder="Enter client remark">{{ $remarks['client']->description ?? '' }}</textarea>
                                            </div>

                                            <div class="form-group mb-3 col-md-4">
                                                <label for="account_remark">Account Remark <span
                                                        class="text-danger">*</span></label>
                                                <textarea name="account_remark" id="account_remark" class="form-control" rows="2"
                                                    placeholder="Enter account remark">{{ $remarks['account']->description ?? '' }}</textarea>
                                            </div>

                                            <div class="form-group mb-3 col-md-4">
                                                <label for="office_remark">Office Remark <span
                                                        class="text-danger">*</span></label>
                                                <textarea name="office_remark" id="office_remark" class="form-control" rows="2"
                                                    placeholder="Enter office remark">{{ $remarks['office']->description ?? '' }}</textarea>
                                            </div>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                            <button type="button" class="btn btn-secondary"
                                                onclick="previousTab(5)">Previous</button>
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>




            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            @include('shared.footer')
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>

    <!-- Modal for Adding/Editing Passenger -->
    <div class="modal fade" id="passengerModal" tabindex="-1" role="dialog" aria-labelledby="passengerModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="passengerForm">
                    @csrf
                    <!-- Include booking_id as a hidden input -->
                    <input type="hidden" name="booking_id" value="{{ $booking->id }}">
                    <input type="hidden" name="passenger_id" id="passenger_id">
                    <input type="hidden" id="_method" value="POST">

                    <div class="modal-header">
                        <h5 class="modal-title" id="passengerModalLabel">Add/Edit Passenger</h5>
                        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="passenger_name">Name</label>
                            <input type="text" name="name" id="passenger_name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="passenger_age">Age</label>
                            <input type="number" name="age" id="passenger_age" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="passenger_gender">Gender</label>
                            <select name="gender" id="passenger_gender" class="form-control" required>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript for handling form submissions and AJAX requests -->
    <script>
        $(document).ready(function() {
            // Show modal for adding a new passenger
            $('#addPassengerBtn').click(function() {
                $('#passengerModalLabel').text('Add Passenger');
                $('#passengerForm')[0].reset();
                $('#passenger_id').val('');
                $('#_method').val('POST'); // Ensure method is POST for new passenger
                $('#passengerModal').modal('show');
            });

            // Show modal for editing an existing passenger
            $('#passengerTable').on('click', '.editPassengerBtn', function() {
                var row = $(this).closest('tr');
                var id = row.data('id');

                $.ajax({
                    url: '/passenger-counts/' + id + '/edit',
                    method: 'GET',
                    success: function(data) {
                        $('#passengerModalLabel').text('Edit Passenger');
                        $('#passenger_id').val(data.id);
                        $('#passenger_name').val(data.name);
                        $('#passenger_age').val(data.age);
                        $('#passenger_gender').val(data.gender);
                        $('#_method').val('PUT'); // Set method to PUT for updating
                        $('#passengerModal').modal('show');
                    }
                });
            });

            // Handle form submission for adding/editing a passenger
            $('#passengerForm').submit(function(e) {
                e.preventDefault();

                var id = $('#passenger_id').val();
                var method = $('#_method').val();
                var url = (id) ? '/passenger-counts/' + id : '/passenger-counts';

                $.ajax({
                    url: url,
                    method: method,
                    data: $(this).serialize(),
                    success: function(response) {
                        location.reload(); // Reload the page to reflect changes
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                        alert('Something went wrong. Please try again.');
                    }
                });
            });

            // Handle passenger deletion
            $('#passengerTable').on('click', '.deletePassengerBtn', function() {
                if (!confirm('Are you sure you want to delete this passenger?')) {
                    return;
                }

                var row = $(this).closest('tr');
                var id = row.data('id');

                $.ajax({
                    url: '/passenger-counts/' + id,
                    method: 'DELETE',
                    data: {
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        row.remove(); // Remove the row from the table
                    },
                    error: function(xhr, status, error) {
                        console.error(xhr.responseText);
                        alert('Something went wrong. Please try again.');
                    }
                });
            });
        });
    </script>
    {{-- -------------------------------- --}}


    <!-- Add/Edit Service Modal -->
    <div class="modal fade" id="serviceModal" tabindex="-1" role="dialog" aria-labelledby="serviceModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="serviceModalLabel">Service Details</h5>
                    <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="serviceForm">
                        @csrf
                        <input type="hidden" name="booking_id" value="{{ $booking->id }}">
                        <input type="hidden" name="service_id" id="service_id"
                            value="{{ isset($service) ? $service->id : '' }}">

                        <div class="form-group">
                            <label for="service_details">Service Details</label>
                            <input type="text" class="form-control" id="service_details" name="service_details"
                                value="{{ isset($service) ? $service->service_details : '' }}" required>
                        </div>

                        <div class="form-group">
                            <label for="travel_date1">Travel Date 1</label>
                            <input type="date" class="form-control" id="travel_date1" name="travel_date1"
                                value="{{ isset($service) ? $service->travel_date1 : '' }}" required>
                        </div>

                        <div class="form-group">
                            <label for="travel_date2">Travel Date 2</label>
                            <input type="date" class="form-control" id="travel_date2" name="travel_date2"
                                value="{{ isset($service) ? $service->travel_date2 : '' }}" required>
                        </div>

                        <div class="form-group">
                            <label for="confirmation_number">Confirmation Number</label>
                            <input type="text" class="form-control" id="confirmation_number" name="confirmation_number"
                                value="{{ isset($service) ? $service->confirmation_number : '' }}" required>
                        </div>
                        <div class="form-group">
                            <label for="gross_amount">Gross Amount</label>
                            <input type="number" class="form-control" id="gross_amount" name="gross_amount"
                                value="{{ isset($service) ? $service->gross_amount : '' }}" step="0.01" required>
                        </div>
                        <div class="form-group">
                            <label for="net">Net Amount</label>
                            <input type="number" class="form-control" id="net" name="net"
                                value="{{ isset($service) ? $service->net : '' }}" step="0.01" required>
                        </div>

                        <div class="form-group">
                            <label for="service_fees">Service Fees</label>
                            <input type="number" class="form-control" id="service_fees" name="service_fees"
                                value="{{ isset($service) ? $service->service_fees : '' }}" step="0.01" required>
                        </div>

                        <div class="form-group">
                            <label for="mask_fees">Mask Fees</label>
                            <input type="number" class="form-control" id="mask_fees" name="mask_fees"
                                value="{{ isset($service) ? $service->mask_fees : '' }}" step="0.01" required>
                        </div>

                        <div class="form-group">
                            <label for="bill">Bill</label>
                            <input type="number" class="form-control" id="bill" name="bill"
                                value="{{ isset($service) ? $service->bill : '' }}" step="0.01" required>
                        </div>

                        <div class="form-group">
                            <label for="supplier_id">Supplier</label>
                            <select class="form-control" id="supplier_id" name="supplier_id" required>
                                <option value="">Select Supplier</option>
                                @foreach ($suppliers as $supplier)
                                    <option value="{{ $supplier->id }}"
                                        {{ isset($service) && $service->supplier_id == $supplier->id ? 'selected' : '' }}>
                                        {{ $supplier->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="card_id">Card</label>
                            <select class="form-control" id="card_id" name="card_id" required>
                                <option value="">Select Card</option>
                                @foreach ($cards as $card)
                                    <option value="{{ $card->id }}"
                                        {{ isset($service) && $service->card_id == $card->id ? 'selected' : '' }}>
                                        {{ $card->card_name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="text-right">
                            <button type="submit" class="btn btn-primary" id="saveServiceBtn">Save</button>
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <script>
        $(document).ready(function() {
            // Open the modal for adding a new service
            $('#addServiceBtn').click(function() {
                $('#serviceModalLabel').text('Add Service');
                $('#serviceForm')[0].reset(); // Reset form fields
                $('#service_id').val(''); // Clear hidden service_id
                $('#serviceModal').modal('show'); // Show modal
            });

            // Open the modal for editing an existing service
            $('#serviceTable').on('click', '.editServiceBtn', function() {
                var row = $(this).closest('tr');
                var serviceId = row.data('id');

                // Fetch the service details using AJAX
                $.ajax({
                    url: '{{ route('service-details.edit', ':id') }}'.replace(':id', serviceId),
                    method: 'GET',
                    success: function(data) {
                        $('#serviceModalLabel').text('Edit Service');
                        $('#service_id').val(data.id);
                        $('#service_details').val(data.service_details);
                        $('#travel_date1').val(data.travel_date1);
                        $('#travel_date2').val(data.travel_date2);
                        $('#confirmation_number').val(data.confirmation_number);
                        $('#net').val(data.net);
                        $('#service_fees').val(data.service_fees);
                        $('#mask_fees').val(data.mask_fees);
                        $('#bill').val(data.bill);
                        $('#serviceModal').modal('show');
                    },
                    error: function(xhr) {
                        alert('Failed to fetch service details.');
                        console.log(xhr
                            .responseText); // Log errors to the console for debugging
                    }
                });
            });

            // Save the service details (add or edit)
            $('#serviceForm').submit(function(e) {
                e.preventDefault(); // Prevent the form from submitting the default way

                var serviceId = $('#service_id').val();
                var url = serviceId ? '{{ route('service-details.update', ':id') }}'.replace(':id',
                    serviceId) : '{{ route('service-details.store') }}';
                var method = serviceId ? 'PUT' : 'POST';

                $.ajax({
                    url: url,
                    method: method,
                    data: $(this).serialize(), // Serialize form data
                    success: function(response) {
                        if (response.success) {
                            $('#serviceModal').modal('hide');
                            location.reload(); // Reload the page to update the table
                        } else {
                            // Handle any success response details if needed
                            alert('Service saved successfully.');
                        }
                    },
                    error: function(xhr) {
                        // Display validation errors or server-side errors
                        var errors = xhr.responseJSON.errors;
                        var errorMessage = xhr.responseJSON.message || 'An error occurred.';

                        // Display errors
                        var errorHtml = '<ul>';
                        $.each(errors, function(key, messages) {
                            $.each(messages, function(index, message) {
                                errorHtml += '<li>' + message + '</li>';
                            });
                        });
                        errorHtml += '</ul>';

                        // Show errors in a modal or alert
                        $('#errorAlert').html('Validation Errors: ' + errorHtml).removeClass(
                            'd-none');
                        console.log(xhr
                            .responseText); // Log errors to the console for debugging
                    }
                });
            });

            // Delete a service
            $('#serviceTable').on('click', '.deleteServiceBtn', function() {
                var row = $(this).closest('tr');
                var serviceId = row.data('id');

                if (confirm('Are you sure you want to delete this service?')) {
                    $.ajax({
                        url: '{{ route('service-details.destroy', ':id') }}'.replace(':id',
                            serviceId),
                        method: 'DELETE',
                        data: {
                            _token: '{{ csrf_token() }}'
                        },
                        success: function(response) {
                            if (response.success) {
                                row.remove(); // Remove the row from the table
                            } else {
                                alert('Failed to delete service.');
                            }
                        },
                        error: function(xhr) {
                            alert('Failed to delete service.');
                            console.log(xhr
                                .responseText); // Log errors to the console for debugging
                        }
                    });
                }
            });
        });
    </script>


    {{-- ===========================
     --}}
    <script>
        function nextTab(current) {
            const next = current + 1;
            if (document.querySelector(`#section${next}`)) {
                document.querySelector(`#section${current}`).classList.remove('show', 'active');
                document.querySelector(`#section${next}`).classList.add('show', 'active');
                document.querySelector(`#section${current}-tab`).classList.remove('active');
                document.querySelector(`#section${next}-tab`).classList.add('active');
            }
        }

        function previousTab(current) {
            const previous = current - 1;
            if (document.querySelector(`#section${previous}`)) {
                document.querySelector(`#section${current}`).classList.remove('show', 'active');
                document.querySelector(`#section${previous}`).classList.add('show', 'active');
                document.querySelector(`#section${current}-tab`).classList.remove('active');
                document.querySelector(`#section${previous}-tab`).classList.add('active');
            }
        }
    </script>
@endsection
